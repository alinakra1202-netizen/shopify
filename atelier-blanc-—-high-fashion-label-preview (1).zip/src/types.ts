export interface BrandSettings {
  brandName: string;
  tagline: string;
  dropDate: string;
  editionCode: string;
  limitedPiecesCount: number;
  currency: string;
  price: number;
}

export interface ProductColorway {
  id: string;
  name: string;
  label: string;
  hex: string;
  borderHex?: string;
  previewImage: string;
}

export type ProductSize = 'XS' | 'S' | 'M' | 'L' | 'XL';

export interface ProductSpec {
  label: string;
  value: string;
}

export interface ProductDetailItem {
  id: string;
  name: string;
  subtitle: string;
  edition: string;
  price: number;
  sku: string;
  description: string;
  composition: string;
  weightGsm: number;
  origin: string;
  colorways: ProductColorway[];
  images: {
    hero: string;
    lookbook: string;
    detail: string;
    atelier: string;
  };
  specs: ProductSpec[];
  sizingNotes: string;
}

export interface UpcomingSilhouette {
  id: string;
  number: string;
  name: string;
  category: string;
  stage: 'Schnittkonstruktion' | 'Stoff-Testing' | 'Atelier-Fitting' | 'Musterfreigabe';
  plannedRelease: string;
  description: string;
  materialNotes: string;
  silhouetteType: string;
  isRegistered?: boolean;
}

export interface CartItem {
  productId: string;
  name: string;
  size: ProductSize;
  colorway: ProductColorway;
  price: number;
  quantity: number;
  image: string;
}

export interface WaitlistSubmission {
  email: string;
  fullName?: string;
  selectedSize?: ProductSize;
  colorway?: string;
  notifiedForGeneralDrop: boolean;
  vipCode: string;
  timestamp: string;
}
