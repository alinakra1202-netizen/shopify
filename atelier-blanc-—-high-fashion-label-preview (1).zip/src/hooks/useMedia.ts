import { useState, useEffect } from 'react';

interface MediaData {
  logo: string | null;
  bgPhoto: string | null;
}

export function useMedia(): MediaData {
  const [media, setMedia] = useState<MediaData>(() => {
    if (typeof window !== 'undefined') {
      const localLogo = localStorage.getItem('atelier_custom_logo_url');
      const localBg = localStorage.getItem('atelier_user_uploaded_bg_photo');
      return {
        logo: localLogo || null,
        bgPhoto: localBg || null,
      };
    }
    return { logo: null, bgPhoto: null };
  });

  useEffect(() => {
    let isMounted = true;

    const syncMedia = () => {
      const localLogo = typeof window !== 'undefined' ? localStorage.getItem('atelier_custom_logo_url') : null;
      const localBg = typeof window !== 'undefined' ? localStorage.getItem('atelier_user_uploaded_bg_photo') : null;

      // 1. Fetch server state first
      fetch('/api/media')
        .then((res) => res.json())
        .then((serverData: MediaData) => {
          if (!isMounted) return;

          // If server already has the files, use them
          const finalLogo = serverData.logo || localLogo;
          const finalBg = serverData.bgPhoto || localBg;

          setMedia({
            logo: finalLogo,
            bgPhoto: finalBg,
          });

          // If local has something that server doesn't, or local has raw base64 data, push it to server!
          if (
            (localLogo && localLogo !== serverData.logo) ||
            (localBg && localBg !== serverData.bgPhoto)
          ) {
            fetch('/api/media', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                logo: localLogo,
                bgPhoto: localBg,
              }),
            })
              .then((res) => res.json())
              .then((result) => {
                if (result.data) {
                  if (result.data.logo) {
                    localStorage.setItem('atelier_custom_logo_url', result.data.logo);
                  }
                  if (result.data.bgPhoto) {
                    localStorage.setItem('atelier_user_uploaded_bg_photo', result.data.bgPhoto);
                  }
                  if (isMounted) {
                    setMedia({
                      logo: result.data.logo,
                      bgPhoto: result.data.bgPhoto,
                    });
                  }
                }
              })
              .catch(console.error);
          }
        })
        .catch(() => {
          // If server not reached, use local
          if (isMounted) {
            setMedia({
              logo: localLogo,
              bgPhoto: localBg,
            });
          }
        });
    };

    syncMedia();

    // Run again once after 1.5s to ensure full sync
    const timer = setTimeout(syncMedia, 1500);

    return () => {
      isMounted = false;
      clearTimeout(timer);
    };
  }, []);

  return media;
}
