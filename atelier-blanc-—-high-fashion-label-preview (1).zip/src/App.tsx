/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { initialBrandSettings } from './data/brandData';
import { BrandSettings, CartItem, ProductSize, ProductColorway } from './types';
import { Header } from './components/Header';
import { ImmersiveHero } from './components/ImmersiveHero';
import { ShopAllPage } from './components/ShopAllPage';
import { DropAccessModal } from './components/DropAccessModal';
import { SizeGuideModal } from './components/SizeGuideModal';
import { LegalModal } from './components/LegalModal';
import { CartDrawer } from './components/CartDrawer';
import { NavigationDrawer } from './components/NavigationDrawer';
import { ProfileModal } from './components/ProfileModal';
import { FounderCustomizer } from './components/FounderCustomizer';
import { Footer } from './components/Footer';
import { Check, Instagram } from 'lucide-react';
import { useMedia } from './hooks/useMedia';

export default function App() {
  const [brandSettings, setBrandSettings] = useState<BrandSettings>(initialBrandSettings);
  const [activePage, setActivePage] = useState<'home' | 'shop-all'>('home');
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isDropModalOpen, setIsDropModalOpen] = useState(false);
  const [isSizeGuideModalOpen, setIsSizeGuideModalOpen] = useState(false);
  const [selectedLegalType, setSelectedLegalType] = useState<string | null>(null);
  const [isCustomizerOpen, setIsCustomizerOpen] = useState(false);
  const [isNavDrawerOpen, setIsNavDrawerOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const media = useMedia();

  const showToast = (message: string) => {
    setToastMessage(message);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  const handleAddToCart = (item: {
    productId: string;
    name: string;
    size: ProductSize;
    colorway: ProductColorway;
    price: number;
    quantity: number;
    image: string;
  }) => {
    setCartItems((prev) => {
      const existingIndex = prev.findIndex(
        (ci) => ci.productId === item.productId && ci.size === item.size && ci.colorway.id === item.colorway.id
      );
      if (existingIndex > -1) {
        const copy = [...prev];
        copy[existingIndex].quantity += item.quantity;
        return copy;
      }
      return [...prev, item];
    });
    showToast(`"${item.name}" wurde zum Warenkorb hinzugefügt.`);
    setIsCartOpen(true);
  };

  const handleRemoveItem = (index: number) => {
    const updated = cartItems.filter((_, i) => i !== index);
    setCartItems(updated);
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  const handleUpdateBrandSettings = (newSettings: Partial<BrandSettings>) => {
    setBrandSettings((prev) => ({
      ...prev,
      ...newSettings,
    }));
  };

  const handleResetBrandDefaults = () => {
    setBrandSettings(initialBrandSettings);
    showToast('Standard-Markenwerte wiederhergestellt.');
  };

  return (
    <div className="min-h-screen bg-white text-zinc-900 selection:bg-zinc-950 selection:text-white flex flex-col font-sans-brand">
      {/* Main Top Header */}
      <Header
        brandSettings={brandSettings}
        cartCount={cartItems.reduce((acc, item) => acc + item.quantity, 0)}
        onOpenNavDrawer={() => setIsNavDrawerOpen(true)}
        onOpenProfileModal={() => setIsProfileModalOpen(true)}
        onOpenCart={() => setIsCartOpen(true)}
        isDark={activePage === 'shop-all'}
        logoUrl={media.logo}
      />

      {/* Main Content Area */}
      <main className="flex-grow">
        {activePage === 'shop-all' ? (
          <ShopAllPage
            brandSettings={brandSettings}
            onBackToHome={() => {
              setActivePage('home');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onAddToCart={handleAddToCart}
            onOpenCart={() => setIsCartOpen(true)}
            cartCount={cartItems.reduce((acc, item) => acc + item.quantity, 0)}
          />
        ) : (
          <>
            <ImmersiveHero
              brandSettings={brandSettings}
              onOpenShopAll={() => {
                setActivePage('shop-all');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              bgPhoto={media.bgPhoto}
            />

            {/* Instagram section right below the hero section */}
            <div className="w-full bg-white pt-6 pb-12 px-4 text-center space-y-3">
              <p className="text-sm sm:text-base uppercase tracking-[0.3em] text-zinc-900 font-semibold">
                Follow us on Instagram
              </p>
              <div className="flex justify-center">
                <a
                  href="https://instagram.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center p-2.5 text-zinc-900 hover:text-zinc-950 transition-colors cursor-pointer"
                  title="Instagram"
                >
                  <Instagram className="w-7 h-7 stroke-[1.75]" />
                </a>
              </div>
            </div>
          </>
        )}
      </main>

      {/* Footer */}
      <Footer
        brandSettings={brandSettings}
        onOpenDropModal={() => setIsDropModalOpen(true)}
        onOpenSizeGuide={() => setIsSizeGuideModalOpen(true)}
        onOpenCustomizer={() => setIsCustomizerOpen(true)}
        onOpenLegal={(type) => setSelectedLegalType(type)}
        logoUrl={media.logo}
      />

      {/* Slide-out Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onRemoveItem={handleRemoveItem}
        brandSettings={brandSettings}
        onClearCart={handleClearCart}
      />

      {/* Navigation & Categories Slide-out Drawer (Left) */}
      <NavigationDrawer
        isOpen={isNavDrawerOpen}
        onClose={() => setIsNavDrawerOpen(false)}
        brandSettings={brandSettings}
        onOpenDropModal={() => setIsDropModalOpen(true)}
        onOpenSizeGuide={() => setIsSizeGuideModalOpen(true)}
        onOpenShopAll={() => {
          setActivePage('shop-all');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenHome={() => {
          setActivePage('home');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />

      {/* Customer Account & Orders Modal (Right) */}
      <ProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        brandSettings={brandSettings}
      />

      {/* VIP Drop Access Modal */}
      <DropAccessModal
        isOpen={isDropModalOpen}
        onClose={() => setIsDropModalOpen(false)}
        brandSettings={brandSettings}
      />

      {/* Size Guide & Fit Advisor Modal */}
      <SizeGuideModal
        isOpen={isSizeGuideModalOpen}
        onClose={() => setIsSizeGuideModalOpen(false)}
        onSelectSize={(size) => {
          showToast(`Empfohlene Größe ${size} ausgewählt.`);
        }}
      />

      {/* Legal Modal */}
      <LegalModal
        isOpen={Boolean(selectedLegalType)}
        onClose={() => setSelectedLegalType(null)}
        legalType={selectedLegalType}
        brandSettings={brandSettings}
      />

      {/* Live Brand Customizer for the Founder */}
      <FounderCustomizer
        isOpen={isCustomizerOpen}
        onClose={() => setIsCustomizerOpen(false)}
        brandSettings={brandSettings}
        onUpdateBrandSettings={handleUpdateBrandSettings}
        onResetDefaults={handleResetBrandDefaults}
      />

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 left-6 z-50 bg-zinc-900 text-white text-xs px-4 py-3 shadow-lg border border-zinc-800 flex items-center gap-2.5 animate-in fade-in slide-in-from-bottom-2">
          <Check className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
