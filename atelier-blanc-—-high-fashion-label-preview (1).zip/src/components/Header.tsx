import React from 'react';
import { Menu, User, ShoppingBag } from 'lucide-react';
import { BrandLogo } from './BrandLogo';
import { BrandSettings } from '../types';

interface HeaderProps {
  brandSettings: BrandSettings;
  cartCount: number;
  onOpenNavDrawer: () => void;
  onOpenProfileModal: () => void;
  onOpenCart: () => void;
  isDark?: boolean;
  logoUrl?: string | null;
}

export const Header: React.FC<HeaderProps> = ({
  cartCount,
  onOpenNavDrawer,
  onOpenProfileModal,
  onOpenCart,
  isDark = false,
  logoUrl,
}) => {
  const tickerItems = [
    'Versandkostenfrei in DE',
    'First Drop',
    'Project Love',
  ];

  return (
    <header className={`absolute top-0 left-0 right-0 z-50 transition-all flex flex-col ${isDark ? 'bg-white border-b border-zinc-200' : ''}`}>
      {/* Top Announcement Bar (Only on home / when not dark) */}
      {!isDark && (
        <>
          <div className="block md:hidden w-full bg-white text-zinc-950 border-b border-zinc-200/80 py-1.5 overflow-hidden whitespace-nowrap text-[10px] tracking-[0.25em] uppercase font-medium">
            <div className="animate-marquee flex items-center">
              {[0, 1].map((_, i) => (
                <div key={i} className="flex items-center shrink-0">
                  {tickerItems.map((item, idx) => (
                    <React.Fragment key={idx}>
                      <span className="px-4">{item}</span>
                      <span className="text-zinc-400 px-2" aria-hidden="true">•</span>
                    </React.Fragment>
                  ))}
                </div>
              ))}
            </div>
          </div>

          <div className="hidden md:flex w-full bg-white text-zinc-950 border-b border-zinc-200/80 py-1.5 items-center justify-center text-[10px] tracking-[0.25em] uppercase font-medium gap-3">
            {tickerItems.map((item, idx) => (
              <React.Fragment key={idx}>
                <span>{item}</span>
                {idx < tickerItems.length - 1 && <span className="text-zinc-400 px-2" aria-hidden="true">•</span>}
              </React.Fragment>
            ))}
          </div>
        </>
      )}

      {/* Main Navigation Header Row */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between w-full">
        {/* Left: 3 horizontal stripes (Hamburger Menu) */}
        <div className="w-24 sm:w-32 flex items-center shrink-0">
          <button
            type="button"
            onClick={onOpenNavDrawer}
            className={`p-2 -ml-2 transition-colors flex items-center gap-2 group cursor-pointer ${
              isDark ? 'text-zinc-950 hover:text-zinc-600' : 'text-white hover:text-zinc-300 drop-shadow-md'
            }`}
            aria-label="Kategorien und Menü öffnen"
            title="Kategorien & Menü"
          >
            <Menu className="w-6 h-6 stroke-[1.5]" />
            <span className={`hidden sm:inline-block text-xs uppercase tracking-[0.18em] font-medium transition-colors ${
              isDark ? 'text-zinc-950' : 'text-white/95 group-hover:text-white'
            }`}>
              Menü
            </span>
          </button>
        </div>

        {/* Center: Brand Logo */}
        <div className="flex-1 flex items-center justify-center">
          <a
            href="#"
            className="inline-flex items-center justify-center p-1 group cursor-pointer"
            aria-label="Zur Startseite"
            title="Zur Startseite scrollen"
          >
            <BrandLogo
              logoUrl={logoUrl}
              className={`h-10 sm:h-12 w-auto transition-transform duration-300 group-hover:scale-105 ${
                isDark ? 'text-zinc-950' : 'brightness-0 invert drop-shadow-md'
              }`}
            />
          </a>
        </div>

        {/* Right: Profile Icon & Bag */}
        <div className="w-24 sm:w-32 flex items-center justify-end gap-1 sm:gap-2 shrink-0">
          <button
            type="button"
            onClick={onOpenProfileModal}
            className={`p-2 transition-colors flex items-center gap-1.5 group cursor-pointer ${
              isDark ? 'text-zinc-950 hover:text-zinc-600' : 'text-white hover:text-zinc-300 drop-shadow-md'
            }`}
            aria-label="Kundenkonto & Bestellungen"
            title="Anmelden / Bestellungen ansehen"
          >
            <User className="w-5 h-5 stroke-[1.5]" />
            <span className={`hidden sm:inline-block text-xs uppercase tracking-[0.16em] font-medium transition-colors ${
              isDark ? 'text-zinc-950' : 'text-white/95 group-hover:text-white'
            }`}>
              Konto
            </span>
          </button>

          <button
            type="button"
            onClick={onOpenCart}
            className={`relative p-2 transition-colors cursor-pointer ${
              isDark ? 'text-zinc-950 hover:text-zinc-600' : 'text-white hover:text-zinc-300 drop-shadow-md'
            }`}
            aria-label="Warenkorb öffnen"
            title="Warenkorb"
          >
            <ShoppingBag className="w-5 h-5 stroke-[1.5]" />
            {cartCount > 0 && (
              <span className={`absolute top-1 right-1 w-4 h-4 text-[10px] font-bold flex items-center justify-center rounded-full tabular-nums shadow ${
                isDark ? 'bg-zinc-950 text-white' : 'bg-white text-zinc-950'
              }`}>
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
