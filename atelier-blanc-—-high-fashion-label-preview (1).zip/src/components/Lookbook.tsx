import React, { useState } from 'react';
import { lookbookItems } from '../data/brandData';
import { Maximize2, X, ChevronRight, ChevronLeft } from 'lucide-react';

export const Lookbook: React.FC = () => {
  const [activeModalIndex, setActiveModalIndex] = useState<number | null>(null);

  const openLightbox = (index: number) => {
    setActiveModalIndex(index);
  };

  const closeLightbox = () => {
    setActiveModalIndex(null);
  };

  const nextImage = () => {
    if (activeModalIndex !== null) {
      setActiveModalIndex((activeModalIndex + 1) % lookbookItems.length);
    }
  };

  const prevImage = () => {
    if (activeModalIndex !== null) {
      setActiveModalIndex((activeModalIndex - 1 + lookbookItems.length) % lookbookItems.length);
    }
  };

  return (
    <section id="lookbook" className="bg-white py-20 sm:py-28 border-b border-zinc-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="mb-14">
          <div className="flex items-center gap-2 text-xs tracking-[0.2em] uppercase text-zinc-400 mb-2">
            <span>Visuelles Archiv</span>
            <span aria-hidden="true">/</span>
            <span>Kampagne</span>
          </div>
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <h2 className="text-3xl sm:text-4xl font-light text-zinc-950 tracking-tight font-editorial">
              Lookbook Edition 01
            </h2>
            <span className="text-xs uppercase tracking-widest text-zinc-500">
              Fotografiert in natürlichem Raumlicht · Keine Retusche der Textilfasern
            </span>
          </div>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {lookbookItems.map((item, index) => (
            <div
              key={item.id}
              className="group relative bg-zinc-50 border border-zinc-100 overflow-hidden cursor-pointer flex flex-col"
              onClick={() => openLightbox(index)}
            >
              <div className="relative aspect-[3/4] overflow-hidden bg-zinc-100">
                <img
                  src={item.image}
                  alt={item.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-black/10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <div className="p-2.5 bg-white/90 text-zinc-900 rounded-full shadow-sm">
                    <Maximize2 className="w-4 h-4" />
                  </div>
                </div>
              </div>

              {/* Caption */}
              <div className="p-4 bg-white flex flex-col justify-between flex-grow border-t border-zinc-50">
                <div>
                  <span className="block text-xs font-medium text-zinc-900 uppercase tracking-wider mb-1">
                    {item.title}
                  </span>
                  <p className="text-[11px] text-zinc-500 line-clamp-2 font-light">
                    {item.caption}
                  </p>
                </div>
                <span className="text-[10px] text-zinc-400 uppercase tracking-widest mt-3 block">
                  {item.location}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox Modal */}
      {activeModalIndex !== null && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
          <button
            type="button"
            onClick={closeLightbox}
            className="absolute top-6 right-6 p-2 text-white/80 hover:text-white transition-colors"
            aria-label="Schließen"
          >
            <X className="w-6 h-6" />
          </button>

          <button
            type="button"
            onClick={prevImage}
            className="absolute left-4 sm:left-8 top-1/2 -translate-y-1/2 p-3 text-white/80 hover:text-white bg-black/40 hover:bg-black/60 transition-colors"
            aria-label="Vorheriges Bild"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          <button
            type="button"
            onClick={nextImage}
            className="absolute right-4 sm:right-8 top-1/2 -translate-y-1/2 p-3 text-white/80 hover:text-white bg-black/40 hover:bg-black/60 transition-colors"
            aria-label="Nächstes Bild"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          <div className="max-w-4xl max-h-[85vh] flex flex-col items-center">
            <img
              src={lookbookItems[activeModalIndex].image}
              alt={lookbookItems[activeModalIndex].title}
              referrerPolicy="no-referrer"
              className="max-h-[70vh] w-auto object-contain border border-white/10"
            />
            <div className="mt-4 text-center text-white max-w-xl">
              <h4 className="text-lg font-light font-editorial">
                {lookbookItems[activeModalIndex].title}
              </h4>
              <p className="text-xs text-zinc-400 mt-1">
                {lookbookItems[activeModalIndex].caption}
              </p>
              <span className="text-[10px] text-zinc-500 uppercase tracking-widest mt-2 block">
                {lookbookItems[activeModalIndex].location} · {activeModalIndex + 1} / {lookbookItems.length}
              </span>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
