import React, { useState, useEffect } from 'react';

interface BrandLogoProps {
  className?: string;
  size?: number;
  logoUrl?: string | null;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  className = 'h-10 w-auto',
  size,
  logoUrl,
}) => {
  const [currentLogo, setCurrentLogo] = useState<string | null>(logoUrl || null);
  const [loadFailed, setLoadFailed] = useState<boolean>(false);

  useEffect(() => {
    if (logoUrl) {
      setCurrentLogo(logoUrl);
      setLoadFailed(false);
      return;
    }
    const saved = localStorage.getItem('atelier_custom_logo_url');
    if (saved) {
      setCurrentLogo(saved);
      setLoadFailed(false);
    }
  }, [logoUrl]);

  const activeSrc = currentLogo || '/custom_brand_logo.png';

  if (!loadFailed && activeSrc) {
    return (
      <img
        src={activeSrc}
        onError={() => setLoadFailed(true)}
        alt="Brand Logo"
        className={`${className} object-contain`}
        style={size ? { height: size, width: 'auto' } : undefined}
        referrerPolicy="no-referrer"
      />
    );
  }

  return (
    <span className="text-xl sm:text-2xl font-bold tracking-[0.25em] uppercase font-sans-brand text-zinc-950">
      NOAR KS
    </span>
  );
};
