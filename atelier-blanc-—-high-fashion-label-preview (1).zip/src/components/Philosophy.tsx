import React from 'react';
import { Layers, Scissors, ShieldAlert, Sparkles, Compass } from 'lucide-react';
import { BrandSettings } from '../types';

interface PhilosophyProps {
  brandSettings: BrandSettings;
}

export const Philosophy: React.FC<PhilosophyProps> = ({ brandSettings }) => {
  return (
    <section id="philosophie" className="bg-white py-20 sm:py-28 border-b border-zinc-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Editorial Subtitle */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs uppercase tracking-[0.25em] text-zinc-400 font-medium block mb-3">
            Das Atelier Manifest
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-light text-zinc-950 tracking-tight font-editorial leading-tight">
            Warum starten wir mit <span className="italic font-normal">nur einem</span> Kleidungsstück?
          </h2>
          <p className="mt-4 text-base sm:text-lg text-zinc-600 font-light leading-relaxed">
            Wir glauben nicht an künstlich aufgeblähte 50-teilige Kollektionen oder saisonale Schnellschüsse. 
            Eine echte Modemarke entsteht aus der Besessenheit für den perfekten Schnitt.
          </p>
        </div>

        {/* 3 Editorial Pillars (Unboxed Clean Aesthetic, White Surfaces with Hairline Borders) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="p-8 border border-zinc-100 bg-white hover:border-zinc-300 transition-colors flex flex-col justify-between">
            <div className="space-y-4">
              <span className="text-xs font-mono tracking-widest text-zinc-400 block">
                PRINZIP 01
              </span>
              <h3 className="text-xl font-normal text-zinc-950 font-editorial">
                Radikale Konzentration
              </h3>
              <p className="text-sm text-zinc-600 font-light leading-relaxed">
                Statt zehn durchschnittliche Produkte anzubieten, haben wir monatelang an jedem Millimeter 
                dieses Pullovers gearbeitet. Vom Halsausschnitt bis zum Ärmelfall: Jede Naht existiert aus einem Grund.
              </p>
            </div>
            <div className="pt-6 mt-6 border-t border-zinc-100 text-xs text-zinc-400 uppercase tracking-wider">
              Kein Massen Sortiment · Reine Substanz
            </div>
          </div>

          <div className="p-8 border border-zinc-100 bg-white hover:border-zinc-300 transition-colors flex flex-col justify-between">
            <div className="space-y-4">
              <span className="text-xs font-mono tracking-widest text-zinc-400 block">
                PRINZIP 02
              </span>
              <h3 className="text-xl font-normal text-zinc-950 font-editorial">
                Textilschwere (600 GSM)
              </h3>
              <p className="text-sm text-zinc-600 font-light leading-relaxed">
                Ein zeitgenössisches Statement-Piece benötigt physische Präsenz. Unsere 600 GSM Doppelbindung 
                aus GOTS-Bio-Baumwolle und feiner Merinowolle fällt architektonisch sauber und verzieht sich niemals beim Waschen.
              </p>
            </div>
            <div className="pt-6 mt-6 border-t border-zinc-100 text-xs text-zinc-400 uppercase tracking-wider">
              Doppeltes Garnvolumen · Ewige Form
            </div>
          </div>

          <div className="p-8 border border-zinc-100 bg-white hover:border-zinc-300 transition-colors flex flex-col justify-between">
            <div className="space-y-4">
              <span className="text-xs font-mono tracking-widest text-zinc-400 block">
                PRINZIP 03
              </span>
              <h3 className="text-xl font-normal text-zinc-950 font-editorial">
                Limitierte Fertigung
              </h3>
              <p className="text-sm text-zinc-600 font-light leading-relaxed">
                Jede Edition wird in kleinen, nummerierten Chargen in einer familiengeführten Manufaktur 
                in Guimarães gefertigt. Keine Lagerüberhänge, keine Rabatt Schlachten, nur ehrliche Wertarbeit.
              </p>
            </div>
            <div className="pt-6 mt-6 border-t border-zinc-100 text-xs text-zinc-400 uppercase tracking-wider">
              Nummeriert auf {brandSettings.limitedPiecesCount} Stück weltweit
            </div>
          </div>
        </div>

        {/* Editorial Quote Banner */}
        <div className="mt-14 p-8 sm:p-12 border border-zinc-200 bg-zinc-50/50 text-center max-w-4xl mx-auto">
          <blockquote className="text-xl sm:text-2xl font-light text-zinc-900 font-editorial italic leading-relaxed">
            „Ein Designerhaus beweist seine Identität nicht über die Masse im Regal, sondern über die Silhouette, die man aus 50 Metern Entfernung sofort wiedererkennt.“
          </blockquote>
          <div className="mt-4 text-xs uppercase tracking-[0.2em] text-zinc-500 font-medium">
            Atelier Leitung und Gründer Notiz · {brandSettings.brandName}
          </div>
        </div>
      </div>
    </section>
  );
};
