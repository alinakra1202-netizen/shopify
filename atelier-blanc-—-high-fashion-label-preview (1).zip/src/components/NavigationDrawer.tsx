import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { BrandSettings } from '../types';
import { BrandLogo } from './BrandLogo';

interface NavigationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  brandSettings: BrandSettings;
  onOpenDropModal: () => void;
  onOpenSizeGuide: () => void;
  onOpenShopAll: () => void;
  onOpenHome: () => void;
  onSelectCategory?: (category: string) => void;
}

export const NavigationDrawer: React.FC<NavigationDrawerProps> = ({
  isOpen,
  onClose,
  brandSettings: _brandSettings,
  onOpenDropModal,
  onOpenShopAll,
  onOpenHome,
}) => {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    if (isOpen) {
      requestAnimationFrame(() => setMounted(true));
    } else {
      setMounted(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden flex justify-start">
      {/* Backdrop with smooth fade transition */}
      <div 
        className={`fixed inset-0 bg-black/50 backdrop-blur-xs transition-opacity duration-300 ease-out ${mounted ? 'opacity-100' : 'opacity-0'}`} 
        onClick={onClose} 
        aria-hidden="true" 
      />

      {/* Drawer Panel sliding smoothly from left to right */}
      <div className={`relative w-[75vw] sm:w-[380px] max-w-md bg-white h-full shadow-2xl flex flex-col justify-between z-10 border-r border-zinc-200 transition-transform duration-300 ease-out transform ${mounted ? 'translate-x-0' : '-translate-x-full'}`}>
        {/* Top bar with centered logo and close button */}
        <div className="p-6 border-b border-zinc-100 flex items-center justify-between relative">
          <div className="w-8" aria-hidden="true" />
          <div className="absolute left-1/2 -translate-x-1/2 flex items-center justify-center">
            <BrandLogo className="h-8 w-auto" />
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-zinc-500 hover:text-zinc-950 transition-colors ml-auto"
            aria-label="Menü schließen"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Menu items */}
        <div className="flex-1 overflow-y-auto px-6 py-6">
          <nav className="space-y-1">
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenHome();
              }}
              className="w-full text-left py-2.5 text-zinc-950 font-medium hover:text-zinc-600 transition-colors cursor-pointer border-b border-zinc-100"
            >
              <span className="text-sm uppercase tracking-wider">HOME</span>
            </button>

            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenShopAll();
              }}
              className="w-full text-left py-2.5 text-zinc-950 font-medium hover:text-zinc-600 transition-colors cursor-pointer border-b border-zinc-100"
            >
              <span className="text-sm uppercase tracking-wider">SHOP ALL</span>
            </button>

            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenDropModal();
              }}
              className="w-full text-left py-2.5 text-zinc-950 font-medium hover:text-zinc-600 transition-colors cursor-pointer border-b border-zinc-100"
            >
              <span className="text-sm uppercase tracking-wider">FIRST DROP</span>
            </button>
          </nav>
        </div>

        {/* Empty bottom spacer for clean balance */}
        <div className="p-6 border-t border-zinc-100" />
      </div>
    </div>
  );
};
