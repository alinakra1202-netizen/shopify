import React, { useState } from 'react';
import { UpcomingSilhouette } from '../types';
import { Bell, Check, Clock, Sparkles, ArrowRight } from 'lucide-react';

interface RoadmapArchiveProps {
  silhouettes: UpcomingSilhouette[];
  onNotifySilhouette: (silhouette: UpcomingSilhouette) => void;
}

export const RoadmapArchive: React.FC<RoadmapArchiveProps> = ({
  silhouettes,
  onNotifySilhouette,
}) => {
  const [notifiedIds, setNotifiedIds] = useState<string[]>([]);

  const handleNotify = (item: UpcomingSilhouette) => {
    if (!notifiedIds.includes(item.id)) {
      setNotifiedIds([...notifiedIds, item.id]);
      onNotifySilhouette(item);
    }
  };

  return (
    <section id="entwicklung" className="bg-white py-20 sm:py-28 border-b border-zinc-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="max-w-2xl">
            <span className="text-xs uppercase tracking-[0.25em] text-zinc-400 font-medium block mb-2">
              Atelier Roadmap
            </span>
            <h2 className="text-3xl sm:text-4xl font-light text-zinc-950 tracking-tight font-editorial">
              Silhouetten in aktiver Entwicklung
            </h2>
            <p className="mt-3 text-zinc-600 text-sm sm:text-base font-light">
              Wir erweitern das Markenuniversum Schritt für Schritt. Jedes künftige Teil durchläuft 
              dieselbe kompromisslose Iterationsphase wie unser Debüt Pullover.
            </p>
          </div>

          <div className="text-xs uppercase tracking-widest text-zinc-400 border-l border-zinc-200 pl-4">
            Status: Labor und Schnittentwicklung
          </div>
        </div>

        {/* 3 Silhouette Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {silhouettes.map((item) => {
            const isNotified = notifiedIds.includes(item.id);
            return (
              <div
                key={item.id}
                className="bg-white border border-zinc-200 p-7 flex flex-col justify-between hover:border-zinc-400 transition-all group"
              >
                <div>
                  {/* Top metadata line */}
                  <div className="flex items-center justify-between text-xs pb-4 border-b border-zinc-100">
                    <span className="font-mono text-zinc-400">SILHOUETTE {item.number}</span>
                    <span className="text-zinc-600 font-medium tracking-wider uppercase text-[11px]">
                      {item.stage}
                    </span>
                  </div>

                  {/* Title & Category */}
                  <div className="pt-5 pb-3">
                    <span className="text-[11px] tracking-widest uppercase text-zinc-400 block mb-1">
                      {item.category} · Geplant {item.plannedRelease}
                    </span>
                    <h3 className="text-xl font-normal text-zinc-950 font-editorial group-hover:text-zinc-700 transition-colors">
                      {item.name}
                    </h3>
                  </div>

                  {/* Description */}
                  <p className="text-xs text-zinc-600 font-light leading-relaxed mb-6">
                    {item.description}
                  </p>

                  {/* Material & Silhouette Specs */}
                  <div className="space-y-2 py-3 border-t border-zinc-100 text-xs">
                    <div>
                      <span className="text-zinc-400 block text-[10px] uppercase tracking-wider">
                        Material
                      </span>
                      <span className="text-zinc-800 font-medium">{item.materialNotes}</span>
                    </div>
                    <div>
                      <span className="text-zinc-400 block text-[10px] uppercase tracking-wider">
                        Schnittprofil
                      </span>
                      <span className="text-zinc-800 font-medium">{item.silhouetteType}</span>
                    </div>
                  </div>
                </div>

                {/* Notify Action */}
                <div className="pt-6 mt-4 border-t border-zinc-100">
                  <button
                    type="button"
                    onClick={() => handleNotify(item)}
                    className={`w-full py-3 px-4 text-xs font-medium tracking-wider uppercase transition-colors flex items-center justify-center gap-2 ${
                      isNotified
                        ? 'bg-zinc-100 text-zinc-900 border border-zinc-300'
                        : 'bg-white hover:bg-zinc-950 hover:text-white text-zinc-900 border border-zinc-300'
                    }`}
                  >
                    {isNotified ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-zinc-950" />
                        <span>Für Release {item.number} vorgemerkt</span>
                      </>
                    ) : (
                      <>
                        <Bell className="w-3.5 h-3.5" />
                        <span>Für Fitting & Release vormerken</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Studio Note */}
        <div className="mt-12 p-6 bg-zinc-50 border border-zinc-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-zinc-600">
          <div className="flex items-center gap-3">
            <span className="w-2 h-2 rounded-full bg-zinc-900 shrink-0" />
            <span>
              Möchtest du eigene Entwürfe einbringen? Als registriertes Community-Mitglied nimmst du an unseren geschlossenen Feedback-Runden teil.
            </span>
          </div>
          <span className="font-mono text-zinc-500 uppercase tracking-wider shrink-0">
            Atelier Archiv V1.0
          </span>
        </div>
      </div>
    </section>
  );
};
