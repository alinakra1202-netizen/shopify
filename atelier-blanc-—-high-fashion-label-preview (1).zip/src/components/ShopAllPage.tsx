import React, { useState, useEffect } from 'react';
import { BrandSettings, ProductSize, ProductColorway, ProductDetailItem } from '../types';
import { debutProduct } from '../data/brandData';

interface ShopAllPageProps {
  brandSettings: BrandSettings;
  onBackToHome: () => void;
  onAddToCart: (item: {
    productId: string;
    name: string;
    size: ProductSize;
    colorway: ProductColorway;
    price: number;
    quantity: number;
    image: string;
  }) => void;
  onOpenCart: () => void;
  cartCount: number;
}

const CATEGORIES = [
  'SWEATSHIRTS',
];

const COLORS = [
  { id: 'schwarz', name: 'Schwarz', hex: '#141415' },
  { id: 'weiss', name: 'Weiss', hex: '#FFFFFF', border: true },
  { id: 'babyblau', name: 'Babyblau', hex: '#89CFF0' },
  { id: 'hellgruen', name: 'Hellgrün', hex: '#98FB98' },
  { id: 'dunkelgruen', name: 'Dunkelgrün', hex: '#1B4D3E' },
  { id: 'pink', name: 'Pink', hex: '#FF69B4' },
  { id: 'dunkelbraun', name: 'Dunkelbraun', hex: '#3D2314' },
  { id: 'navy', name: 'Navy', hex: '#1B2A4A' },
];

const SIZES = ['XXS', 'XS', 'S', 'M', 'L', 'XL', 'XXL'];

export const ShopAllPage: React.FC<ShopAllPageProps> = () => {
  const [selectedCategories, setSelectedCategories] = useState<string[]>(['SWEATSHIRTS']);
  const [selectedColors, setSelectedColors] = useState<string[]>([]);
  const [selectedSizes, setSelectedSizes] = useState<string[]>([]);
  const [inStockOnly, setInStockOnly] = useState(false);

  const [products] = useState<ProductDetailItem[]>(() => {
    const saved = localStorage.getItem('atelier_all_products');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // fallback
      }
    }
    return [debutProduct];
  });

  useEffect(() => {
    localStorage.setItem('atelier_all_products', JSON.stringify(products));
  }, [products]);

  const toggleCategory = (cat: string) => {
    setSelectedCategories((prev) =>
      prev.includes(cat) ? prev.filter((c) => c !== cat) : [...prev, cat]
    );
  };

  const toggleColor = (id: string) => {
    setSelectedColors((prev) =>
      prev.includes(id) ? prev.filter((c) => c !== id) : [...prev, id]
    );
  };

  const toggleSize = (sz: string) => {
    setSelectedSizes((prev) =>
      prev.includes(sz) ? prev.filter((s) => s !== sz) : [...prev, sz]
    );
  };

  const matchingCount = products.length;

  return (
    <div className="min-h-[50vh] bg-white text-zinc-900 font-sans-brand pt-22 pb-12 space-y-2">
      {/* Smaller bold SHOP ALL Title above filter */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        <h1 className="text-xs sm:text-sm font-bold uppercase tracking-[0.2em] text-zinc-950 font-sans-brand">
          SHOP ALL
        </h1>
      </div>

      {/* Compact Filter Bar below header with bottom dividing line */}
      <div className="w-full bg-white py-1.5 px-4 sm:px-8 space-y-2 border-b border-zinc-200">
        <div className="max-w-7xl mx-auto space-y-2 text-[11px] pb-2">
          
          {/* CATEGORY ROW */}
          <div className="flex items-center gap-3 overflow-x-auto pb-1 scrollbar-none">
            <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-400 shrink-0 w-20">
              Category
            </span>
            <div className="flex items-center gap-1.5 shrink-0">
              {CATEGORIES.map((cat) => {
                const isSelected = selectedCategories.includes(cat);
                return (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => toggleCategory(cat)}
                    className={`px-3 py-1 rounded-full text-[10px] font-semibold uppercase tracking-wider transition-all cursor-pointer whitespace-nowrap ${
                      isSelected
                        ? 'bg-white text-zinc-950 border border-zinc-950 shadow-xs'
                        : 'bg-zinc-100 text-zinc-700 hover:bg-zinc-200'
                    }`}
                  >
                    {cat}
                  </button>
                );
              })}
            </div>
          </div>

          {/* COLOR ROW */}
          <div className="flex items-center gap-3 overflow-x-auto pb-1 scrollbar-none">
            <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-400 shrink-0 w-20">
              Color
            </span>
            <div className="flex items-center gap-2.5 shrink-0 py-0.5">
              {COLORS.map((col) => {
                const isSelected = selectedColors.includes(col.id);
                return (
                  <button
                    key={col.id}
                    type="button"
                    onClick={() => toggleColor(col.id)}
                    style={{ backgroundColor: col.hex }}
                    className={`w-5 h-5 rounded-full transition-all cursor-pointer relative shrink-0 shadow-xs ${
                      col.border ? 'border border-zinc-300' : ''
                    } ${isSelected ? 'ring-2 ring-zinc-950 shadow-md' : 'hover:opacity-90'}`}
                    title={col.name}
                  >
                    {isSelected && (
                      <span className={`absolute inset-0 flex items-center justify-center text-[9px] font-bold ${col.id === 'weiss' ? 'text-zinc-950' : 'text-white'}`}>
                        ✓
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* SIZE ROW & IN STOCK TOGGLE */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-0.5">
            <div className="flex items-center gap-3 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
              <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-400 shrink-0 w-20">
                Size
              </span>
              <div className="flex items-center gap-1 shrink-0">
                {SIZES.map((sz) => {
                  const isSelected = selectedSizes.includes(sz);
                  return (
                    <button
                      key={sz}
                      type="button"
                      onClick={() => toggleSize(sz)}
                      className={`px-2 py-0.5 rounded-sm text-[10px] font-medium uppercase tracking-wider transition-all cursor-pointer whitespace-nowrap ${
                        isSelected
                          ? 'bg-zinc-950 text-white shadow-xs'
                          : 'bg-zinc-100 text-zinc-700 hover:bg-zinc-200'
                      }`}
                    >
                      {sz}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* In Stock Toggle */}
            <div className="flex items-center gap-2.5 shrink-0 self-end sm:self-center">
              <span className="text-[10px] uppercase tracking-wider text-zinc-500 font-medium">In Stock</span>
              <button
                type="button"
                onClick={() => setInStockOnly(!inStockOnly)}
                className={`w-8 h-4.5 flex items-center rounded-full p-0.5 transition-colors cursor-pointer ${
                  inStockOnly ? 'bg-zinc-950' : 'bg-zinc-300'
                }`}
              >
                <div
                  className={`bg-white w-3.5 h-3.5 rounded-full shadow-md transform transition-transform ${
                    inStockOnly ? 'translate-x-3.5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          </div>

        </div>
      </div>

      {/* Article count below dividing line on the right */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 flex justify-end pt-2">
        <span className="text-[11px] uppercase tracking-[0.15em] text-zinc-500 font-mono font-medium">
          {matchingCount} {matchingCount === 1 ? 'Artikel' : 'Artikel'}
        </span>
      </div>
    </div>
  );
};
