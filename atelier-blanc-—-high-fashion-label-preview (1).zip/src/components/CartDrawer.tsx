import React, { useState } from 'react';
import { X, Trash2, ShieldCheck, ArrowRight, CheckCircle2 } from 'lucide-react';
import { CartItem, BrandSettings } from '../types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onRemoveItem: (index: number) => void;
  brandSettings: BrandSettings;
  onClearCart: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onRemoveItem,
  brandSettings,
  onClearCart,
}) => {
  const [checkoutStep, setCheckoutStep] = useState<'cart' | 'shipping' | 'confirmed'>('cart');
  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [orderNumber, setOrderNumber] = useState('');

  if (!isOpen) return null;

  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const shippingCost = 0; // Free EU shipping
  const total = subtotal + shippingCost;

  const handleAuthorizeOrder = (e: React.FormEvent) => {
    e.preventDefault();
    const fakeOrder = `BLANC-${Math.floor(100000 + Math.random() * 900000)}`;
    setOrderNumber(fakeOrder);
    setCheckoutStep('confirmed');
  };

  const handleFinish = () => {
    setCheckoutStep('cart');
    onClearCart();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-xs flex justify-end">
      <div className="w-full max-w-md bg-white h-full flex flex-col shadow-2xl relative border-l border-zinc-200">
        {/* Drawer Header */}
        <div className="p-6 border-b border-zinc-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold tracking-[0.15em] uppercase text-zinc-950 font-sans-brand">
              Warenkorb & Drop-Reservierung
            </span>
            <span className="text-xs text-zinc-400 tabular-nums">({items.length})</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-zinc-400 hover:text-zinc-950 transition-colors"
            aria-label="Warenkorb schließen"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Drawer Content */}
        {checkoutStep === 'cart' && (
          <div className="flex-1 overflow-y-auto p-6 flex flex-col justify-between">
            {items.length === 0 ? (
              <div className="text-center py-20 space-y-4">
                <p className="text-sm text-zinc-400 font-light">Dein Warenkorb ist derzeit leer.</p>
                <button
                  type="button"
                  onClick={onClose}
                  className="px-6 py-3 bg-zinc-950 text-white text-xs uppercase tracking-widest font-medium hover:bg-zinc-800 transition-colors"
                >
                  Debüt-Kollektion ansehen
                </button>
              </div>
            ) : (
              <div className="space-y-6">
                {/* Free shipping bar */}
                <div className="p-3 bg-zinc-50 border border-zinc-100 text-xs text-zinc-600 flex items-center justify-between">
                  <span>Kostenfreier versicherter EU-Expressversand</span>
                  <span className="font-semibold text-zinc-950">Aktiv</span>
                </div>

                {/* Items List */}
                <div className="space-y-4 divide-y divide-zinc-100">
                  {items.map((item, idx) => (
                    <div key={idx} className="pt-4 first:pt-0 flex gap-4 items-start">
                      <img
                        src={item.image}
                        alt={item.name}
                        referrerPolicy="no-referrer"
                        className="w-20 h-24 object-cover bg-zinc-100 border border-zinc-200 shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-start">
                          <h4 className="text-sm font-medium text-zinc-950 truncate">{item.name}</h4>
                          <button
                            type="button"
                            onClick={() => onRemoveItem(idx)}
                            className="text-zinc-400 hover:text-red-500 transition-colors ml-2 p-1"
                            title="Entfernen"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                        <p className="text-xs text-zinc-500 mt-1">
                          Farbe: {item.colorway.name} · Größe: {item.size}
                        </p>
                        <p className="text-xs text-zinc-400 mt-0.5">Menge: {item.quantity}</p>
                        <div className="mt-3 text-sm font-light font-editorial text-zinc-950 tabular-nums">
                          {item.price} {brandSettings.currency}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Bottom Actions if items present */}
            {items.length > 0 && (
              <div className="pt-6 border-t border-zinc-100 space-y-4 mt-6">
                <div className="space-y-2 text-xs">
                  <div className="flex justify-between text-zinc-500">
                    <span>Zwischensumme</span>
                    <span className="font-medium text-zinc-950 tabular-nums">
                      {subtotal} {brandSettings.currency}
                    </span>
                  </div>
                  <div className="flex justify-between text-zinc-500">
                    <span>Versand</span>
                    <span className="font-medium text-zinc-950">Kostenlos (DHL Express)</span>
                  </div>
                  <div className="flex justify-between text-base font-semibold text-zinc-950 pt-2 border-t border-zinc-100">
                    <span>Gesamtsumme</span>
                    <span className="tabular-nums font-editorial text-lg">
                      {total} {brandSettings.currency}
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setCheckoutStep('shipping')}
                  className="w-full py-4 bg-zinc-950 hover:bg-zinc-800 text-white font-medium text-xs tracking-[0.18em] uppercase transition-colors flex items-center justify-center gap-2"
                >
                  <span>Zur Vorbestellung / Kasse</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <div className="flex items-center justify-center gap-2 text-[11px] text-zinc-400 pt-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Drop-Kontingent wird für 15 Minuten reserviert</span>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Checkout Shipping Form Step */}
        {checkoutStep === 'shipping' && (
          <form
            onSubmit={handleAuthorizeOrder}
            className="flex-1 overflow-y-auto p-6 flex flex-col justify-between"
          >
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-zinc-100">
                <span className="text-xs uppercase tracking-wider text-zinc-500 font-medium">
                  Versand- & Kundendaten
                </span>
                <button
                  type="button"
                  onClick={() => setCheckoutStep('cart')}
                  className="text-xs text-zinc-900 underline"
                >
                  Zurück zum Warenkorb
                </button>
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-zinc-500 mb-1">
                  Vollständiger Name *
                </label>
                <input
                  type="text"
                  required
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="Max Mustermann"
                  className="w-full px-3 py-2.5 bg-white border border-zinc-200 text-sm focus:border-zinc-950 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-zinc-500 mb-1">
                  E-Mail für Bestellbestätigung *
                </label>
                <input
                  type="email"
                  required
                  value={customerEmail}
                  onChange={(e) => setCustomerEmail(e.target.value)}
                  placeholder="max@beispiel.de"
                  className="w-full px-3 py-2.5 bg-white border border-zinc-200 text-sm focus:border-zinc-950 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-zinc-500 mb-1">
                  Lieferadresse *
                </label>
                <textarea
                  required
                  rows={3}
                  value={customerAddress}
                  onChange={(e) => setCustomerAddress(e.target.value)}
                  placeholder="Straße, Hausnummer, PLZ, Stadt, Land"
                  className="w-full px-3 py-2.5 bg-white border border-zinc-200 text-sm focus:border-zinc-950 focus:outline-none"
                />
              </div>

              <div className="p-3 bg-zinc-50 border border-zinc-100 text-xs text-zinc-600">
                <strong>Zahlungsmethode:</strong> Vorbestellungs-Autorisierung (Keine Abbuchung vor offizieller Fertigstellung im {brandSettings.dropDate}).
              </div>
            </div>

            <div className="pt-6 border-t border-zinc-100 space-y-3">
              <button
                type="submit"
                className="w-full py-4 bg-zinc-950 hover:bg-zinc-800 text-white font-medium text-xs tracking-[0.18em] uppercase transition-colors"
              >
                Vorbestellung kostenpflichtig autorisieren
              </button>
              <p className="text-[10px] text-zinc-400 text-center">
                14 Tage Widerrufsrecht nach Erhalt · Kostenlose Retoure in DE, AT, CH
              </p>
            </div>
          </form>
        )}

        {/* Confirmed Order Step */}
        {checkoutStep === 'confirmed' && (
          <div className="flex-1 overflow-y-auto p-6 flex flex-col justify-between text-center">
            <div className="py-8 space-y-4">
              <div className="w-14 h-14 mx-auto rounded-full bg-zinc-100 flex items-center justify-center text-zinc-950">
                <CheckCircle2 className="w-8 h-8" />
              </div>

              <h3 className="text-2xl font-light text-zinc-950 font-editorial">
                Vorbestellung gesichert
              </h3>

              <div className="p-4 bg-zinc-50 border border-zinc-200 text-left space-y-2 text-xs">
                <div className="flex justify-between text-zinc-500">
                  <span>Bestellnummer:</span>
                  <span className="font-mono text-zinc-950 font-medium">{orderNumber}</span>
                </div>
                <div className="flex justify-between text-zinc-500">
                  <span>Lieferfenster:</span>
                  <span className="text-zinc-950 font-medium">{brandSettings.dropDate}</span>
                </div>
                <div className="flex justify-between text-zinc-500">
                  <span>Empfänger:</span>
                  <span className="text-zinc-950 truncate max-w-[200px]">{customerName || 'Gast'}</span>
                </div>
              </div>

              <p className="text-xs text-zinc-600 leading-relaxed font-light">
                Vielen Dank für dein Vertrauen in unser Atelier. Eine Bestätigungsnachricht wurde an{' '}
                <strong className="text-zinc-900">{customerEmail || 'deine E-Mail'}</strong> gesendet. Sobald die Nummerierung der Stücke erfolgt ist, erhältst du ein Produktions-Update.
              </p>
            </div>

            <div className="pt-6 border-t border-zinc-100">
              <button
                type="button"
                onClick={handleFinish}
                className="w-full py-4 bg-zinc-950 hover:bg-zinc-800 text-white font-medium text-xs tracking-[0.18em] uppercase transition-colors"
              >
                Fertigstellen & Zurück
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
