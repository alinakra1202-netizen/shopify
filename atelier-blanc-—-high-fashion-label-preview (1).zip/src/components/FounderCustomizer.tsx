import React from 'react';
import { X, RotateCcw, Check, SlidersHorizontal, Sparkles } from 'lucide-react';
import { BrandSettings } from '../types';

interface FounderCustomizerProps {
  isOpen: boolean;
  onClose: () => void;
  brandSettings: BrandSettings;
  onUpdateBrandSettings: (newSettings: Partial<BrandSettings>) => void;
  onResetDefaults: () => void;
}

export const FounderCustomizer: React.FC<FounderCustomizerProps> = ({
  isOpen,
  onClose,
  brandSettings,
  onUpdateBrandSettings,
  onResetDefaults,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/50 backdrop-blur-xs flex justify-end">
      <div className="w-full max-w-sm bg-white h-full flex flex-col shadow-2xl relative border-l border-zinc-200">
        {/* Header */}
        <div className="p-6 border-b border-zinc-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <SlidersHorizontal className="w-4 h-4 text-zinc-950" />
            <span className="text-sm font-semibold tracking-wider uppercase text-zinc-950 font-sans-brand">
              Gründer-Werkstatt
            </span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-zinc-400 hover:text-zinc-950 transition-colors"
            aria-label="Schließen"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5 text-xs">
          <div className="p-3 bg-zinc-50 border border-zinc-100 text-zinc-600 leading-relaxed">
            Passe hier deine Markendetails live an, um zu testen, wie dein eigener Markenname und deine Vorstellungen auf der Seite wirken.
          </div>

          <div>
            <label className="block uppercase tracking-wider font-medium text-zinc-600 mb-1">
              Markenname
            </label>
            <input
              type="text"
              value={brandSettings.brandName}
              onChange={(e) => onUpdateBrandSettings({ brandName: e.target.value })}
              className="w-full px-3 py-2 bg-white border border-zinc-300 text-sm focus:border-zinc-950 focus:outline-none"
              placeholder="z.B. ATELIER BLANC"
            />
            <span className="text-[10px] text-zinc-400 mt-1 block">
              Erscheint in Navigation, Footer und Lookbook
            </span>
          </div>

          <div>
            <label className="block uppercase tracking-wider font-medium text-zinc-600 mb-1">
              Drop-Datum
            </label>
            <input
              type="text"
              value={brandSettings.dropDate}
              onChange={(e) => onUpdateBrandSettings({ dropDate: e.target.value })}
              className="w-full px-3 py-2 bg-white border border-zinc-300 text-sm focus:border-zinc-950 focus:outline-none"
              placeholder="z.B. November 2026"
            />
          </div>

          <div>
            <label className="block uppercase tracking-wider font-medium text-zinc-600 mb-1">
              Kollektions-Code
            </label>
            <input
              type="text"
              value={brandSettings.editionCode}
              onChange={(e) => onUpdateBrandSettings({ editionCode: e.target.value })}
              className="w-full px-3 py-2 bg-white border border-zinc-300 text-sm focus:border-zinc-950 focus:outline-none"
              placeholder="z.B. EDITION 01"
            />
          </div>

          <div>
            <label className="block uppercase tracking-wider font-medium text-zinc-600 mb-1">
              Preis des Debüt-Pullovers ({brandSettings.currency})
            </label>
            <input
              type="number"
              value={brandSettings.price}
              onChange={(e) => onUpdateBrandSettings({ price: Number(e.target.value) })}
              className="w-full px-3 py-2 bg-white border border-zinc-300 text-sm focus:border-zinc-950 focus:outline-none"
              placeholder="185"
            />
          </div>

          <div>
            <label className="block uppercase tracking-wider font-medium text-zinc-600 mb-1">
              Limitierung (Stückzahl im ersten Batch)
            </label>
            <input
              type="number"
              value={brandSettings.limitedPiecesCount}
              onChange={(e) => onUpdateBrandSettings({ limitedPiecesCount: Number(e.target.value) })}
              className="w-full px-3 py-2 bg-white border border-zinc-300 text-sm focus:border-zinc-950 focus:outline-none"
              placeholder="150"
            />
          </div>

          <div>
            <label className="block uppercase tracking-wider font-medium text-zinc-600 mb-1">
              Slogan / Leitgedanke
            </label>
            <textarea
              rows={2}
              value={brandSettings.tagline}
              onChange={(e) => onUpdateBrandSettings({ tagline: e.target.value })}
              className="w-full px-3 py-2 bg-white border border-zinc-300 text-xs focus:border-zinc-950 focus:outline-none"
            />
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-6 border-t border-zinc-100 space-y-2">
          <button
            type="button"
            onClick={onClose}
            className="w-full py-3 bg-zinc-950 hover:bg-zinc-800 text-white font-medium text-xs tracking-widest uppercase transition-colors"
          >
            Vorschau übernehmen & schließen
          </button>

          <button
            type="button"
            onClick={onResetDefaults}
            className="w-full py-2.5 bg-white hover:bg-zinc-50 border border-zinc-200 text-zinc-700 text-xs tracking-wider uppercase transition-colors flex items-center justify-center gap-1.5"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Auf Standard zurücksetzen</span>
          </button>
        </div>
      </div>
    </div>
  );
};
