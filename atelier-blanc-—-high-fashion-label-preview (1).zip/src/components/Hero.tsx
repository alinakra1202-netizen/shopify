import React from 'react';
import { ArrowDownRight, ShieldCheck, Sparkles } from 'lucide-react';
import { BrandSettings, ProductDetailItem } from '../types';

interface HeroProps {
  brandSettings: BrandSettings;
  product: ProductDetailItem;
  onOpenDropModal: () => void;
  onScrollToProduct: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  brandSettings,
  product,
  onOpenDropModal,
  onScrollToProduct,
}) => {
  return (
    <section className="relative bg-white pt-6 pb-20 sm:pt-10 sm:pb-28 border-b border-zinc-100 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Subdued Editorial Top Line */}
        <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-zinc-100 text-xs tracking-[0.2em] uppercase text-zinc-500">
          <div className="flex items-center gap-2">
            <span>{brandSettings.editionCode}</span>
            <span aria-hidden="true">·</span>
            <span>Atelier Debüt</span>
            <span aria-hidden="true">·</span>
            <span>Limitierung: {brandSettings.limitedPiecesCount} Exemplare</span>
          </div>
          <div className="flex items-center gap-2">
            <span>Offizieller Drop</span>
            <span aria-hidden="true">·</span>
            <span className="text-zinc-950 font-semibold">{brandSettings.dropDate}</span>
          </div>
        </div>

        {/* 2-Column Split: Editorial Prose & Campaign Visual */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 pt-12 lg:pt-16 items-center">
          {/* Left Column: Brand Statement & Garment Focus */}
          <div className="lg:col-span-6 flex flex-col justify-center space-y-8">
            <div className="space-y-4">
              <span className="text-xs uppercase tracking-[0.25em] font-medium text-zinc-400 block">
                Erstes Kapitel der Marke
              </span>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-light tracking-tight text-zinc-950 leading-[1.08] font-editorial">
                Der erste Schritt. <br />
                <span className="italic font-normal">Ein einzelnes, vollendetes</span> Stück.
              </h1>
              <p className="text-base sm:text-lg text-zinc-600 font-light leading-relaxed max-w-xl pt-2">
                Bevor wir ein ganzes Sortiment entwerfen, widmen wir uns der Perfektion eines einzigen Kleidungsstücks. 
                Der <strong className="font-medium text-zinc-900">{product.name}</strong> vereint 600 GSM Textilgewicht, 
                eine skulpturale Boxy Passform und makellose europäische Handwerkskunst.
              </p>
            </div>

            {/* Spec Highlights Grid (Unboxed Clean Metadata) */}
            <div className="grid grid-cols-3 gap-6 pt-2 pb-2 border-y border-zinc-100 text-zinc-900">
              <div>
                <span className="block text-2xl sm:text-3xl font-light font-editorial tabular-nums">
                  {product.weightGsm}
                </span>
                <span className="text-[11px] tracking-wider uppercase text-zinc-500">
                  GSM Textildichte
                </span>
              </div>
              <div>
                <span className="block text-2xl sm:text-3xl font-light font-editorial tabular-nums">
                  {brandSettings.limitedPiecesCount}
                </span>
                <span className="text-[11px] tracking-wider uppercase text-zinc-500">
                  Nummerierte Stücke
                </span>
              </div>
              <div>
                <span className="block text-2xl sm:text-3xl font-light font-editorial tabular-nums">
                  {brandSettings.price} {brandSettings.currency}
                </span>
                <span className="text-[11px] tracking-wider uppercase text-zinc-500">
                  Debüt Einführung
                </span>
              </div>
            </div>

            {/* Primary Actions */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2">
              <button
                type="button"
                onClick={onScrollToProduct}
                className="inline-flex items-center justify-center gap-2 px-7 py-4 text-xs font-semibold tracking-[0.16em] uppercase text-white bg-zinc-950 hover:bg-zinc-800 transition-colors shadow-sm"
              >
                <span>Pullover im Detail</span>
                <ArrowDownRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={onOpenDropModal}
                className="inline-flex items-center justify-center px-7 py-4 text-xs font-semibold tracking-[0.16em] uppercase text-zinc-950 bg-white hover:bg-zinc-50 border border-zinc-200 transition-colors"
              >
                Drop Warteliste beitreten
              </button>
            </div>

            {/* Footnote reassurance */}
            <div className="flex items-center gap-3 text-xs text-zinc-500 pt-1">
              <ShieldCheck className="w-4 h-4 text-zinc-700 shrink-0" />
              <span>Keine Serienproduktion · Frühzeitiger VIP Zugang 2 Stunden vor offiziellem Launch</span>
            </div>
          </div>

          {/* Right Column: Hero High-Fashion Campaign Visual */}
          <div className="lg:col-span-6">
            <div className="relative group bg-zinc-50 border border-zinc-100 overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.04)]">
              <img
                src={product.images.hero}
                alt={`${product.name} — Hochwertiger Pullover im Lookbook`}
                referrerPolicy="no-referrer"
                className="w-full h-[520px] sm:h-[620px] object-cover object-top transition-transform duration-700 group-hover:scale-[1.02]"
              />

              {/* Minimal Editorial Tag on bottom corner */}
              <div className="absolute bottom-4 left-4 right-4 bg-white/95 backdrop-blur-sm p-4 border border-zinc-100/80 flex items-center justify-between text-xs">
                <div>
                  <span className="block font-medium uppercase tracking-wider text-zinc-900 text-[11px]">
                    {product.name}
                  </span>
                  <span className="text-zinc-500 text-[11px]">Chalk White · Doppelter Boxy Schnitt</span>
                </div>
                <button
                  type="button"
                  onClick={onScrollToProduct}
                  className="text-zinc-950 font-semibold uppercase tracking-wider text-[11px] hover:underline"
                >
                  Entdecken →
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
