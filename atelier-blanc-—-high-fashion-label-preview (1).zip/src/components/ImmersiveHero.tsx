import React, { useState, useEffect } from 'react';
import { BrandSettings } from '../types';

interface ImmersiveHeroProps {
  brandSettings: BrandSettings;
  onOpenShopAll: () => void;
  bgPhoto?: string | null;
}

export const ImmersiveHero: React.FC<ImmersiveHeroProps> = ({
  onOpenShopAll,
  bgPhoto,
}) => {
  const [currentBg, setCurrentBg] = useState<string | null>(bgPhoto || null);
  const [imgSrc, setImgSrc] = useState<string>(bgPhoto || '/custom_hero_bg.png');

  useEffect(() => {
    if (bgPhoto) {
      setCurrentBg(bgPhoto);
      setImgSrc(bgPhoto);
      return;
    }
    const saved = localStorage.getItem('atelier_user_uploaded_bg_photo');
    if (saved) {
      setCurrentBg(saved);
      setImgSrc(saved);
    }
  }, [bgPhoto]);

  return (
    <section className="relative w-full min-h-screen bg-white overflow-hidden">
      {/* Background Image full, crisp, no edge cutoffs */}
      <div className="absolute inset-0 z-0 bg-white">
        <img
          src={imgSrc}
          onError={() => {
            if (imgSrc !== '/src/assets/images/hero_fashion_pullover_1791734224058.jpg') {
              setImgSrc('/src/assets/images/hero_fashion_pullover_1791734224058.jpg');
            }
          }}
          alt="Campaign Hero"
          className="w-full h-full min-h-screen object-cover object-left sm:object-center"
          referrerPolicy="no-referrer"
        />
      </div>

      {/* Pure white overlay gradient at the bottom to wash out and transition into white */}
      <div className="absolute bottom-0 left-0 right-0 h-48 sm:h-64 bg-gradient-to-t from-white via-white/95 to-transparent pointer-events-none z-10" />

      {/* SHOP ALL Button placed slightly higher and narrower */}
      <div className="absolute top-[52%] right-[10%] sm:right-[20%] z-20 pointer-events-auto">
        <button
          type="button"
          onClick={onOpenShopAll}
          className="px-4 py-2 bg-white hover:bg-zinc-50 text-zinc-950 text-[11px] uppercase tracking-[0.22em] font-semibold transition-all shadow-md hover:scale-105 active:scale-95 border-2 border-zinc-950 rounded-sm cursor-pointer"
          title="Zum Shop All Katalog"
        >
          SHOP ALL
        </button>
      </div>
    </section>
  );
};
