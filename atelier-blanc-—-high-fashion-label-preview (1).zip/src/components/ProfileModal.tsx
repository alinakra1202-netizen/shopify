import React, { useState } from 'react';
import { X, User, Package, Lock, Mail, CheckCircle2, ArrowRight, LogOut, Clock, ShieldCheck, Ticket } from 'lucide-react';
import { BrandSettings } from '../types';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  brandSettings: BrandSettings;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({
  isOpen,
  onClose,
  brandSettings,
}) => {
  const [activeTab, setActiveTab] = useState<'orders' | 'login' | 'vip'>('orders');
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(true); // Logged in by default with sample order for realistic preview
  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [isRegisterMode, setIsRegisterMode] = useState(false);
  const [userEmail, setUserEmail] = useState('kunde@atelier-blanc.de');
  const [userName, setUserName] = useState('Julian Weber');

  if (!isOpen) return null;

  // Sample order for the debut pullover
  const sampleOrders = [
    {
      id: 'BLANC-892144',
      date: '14. Oktober 2026',
      status: 'In Fertigung (Drop-Kontingent)',
      item: 'Der Sculpted Heavyweight Knit',
      edition: 'Edition 01 / Batch 01',
      details: 'Chalk White · Größe L · 600 GSM',
      price: `${brandSettings.price} ${brandSettings.currency}`,
      tracking: 'DHL Express — Sendungsnummer folgt zum Drop',
      deliveryWindow: brandSettings.dropDate,
      numberedPiece: 'Exemplar 042 / 150',
    },
  ];

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailInput) return;
    setUserEmail(emailInput);
    setUserName(emailInput.split('@')[0]);
    setIsLoggedIn(true);
    setActiveTab('orders');
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setActiveTab('login');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-xs flex justify-end">
      {/* Backdrop */}
      <div className="fixed inset-0" onClick={onClose} aria-hidden="true" />

      {/* Drawer Panel */}
      <div className="relative w-full max-w-md bg-white h-full shadow-2xl flex flex-col justify-between z-10 border-l border-zinc-200 animate-in slide-in-from-right duration-300">
        {/* Header */}
        <div className="p-6 border-b border-zinc-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <User className="w-4 h-4 text-zinc-950" />
            <span className="text-sm font-semibold tracking-wider uppercase text-zinc-950 font-sans-brand">
              Kunden-Konto & Bestellungen
            </span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-zinc-400 hover:text-zinc-950 transition-colors"
            aria-label="Schließen"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation if Logged in */}
        {isLoggedIn ? (
          <div className="px-6 pt-4 border-b border-zinc-100 flex items-center justify-between bg-zinc-50/50">
            <div className="flex gap-6 text-xs uppercase tracking-wider font-medium text-zinc-500">
              <button
                type="button"
                onClick={() => setActiveTab('orders')}
                className={`pb-3 transition-colors ${
                  activeTab === 'orders' ? 'border-b-2 border-zinc-950 text-zinc-950 font-semibold' : 'hover:text-zinc-900'
                }`}
              >
                Bestellungen ({sampleOrders.length})
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('vip')}
                className={`pb-3 transition-colors ${
                  activeTab === 'vip' ? 'border-b-2 border-zinc-950 text-zinc-950 font-semibold' : 'hover:text-zinc-900'
                }`}
              >
                VIP-Pass & Drops
              </button>
            </div>

            <button
              type="button"
              onClick={handleLogout}
              className="text-xs text-zinc-400 hover:text-zinc-950 flex items-center gap-1 pb-3"
              title="Abmelden"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Abmelden</span>
            </button>
          </div>
        ) : (
          <div className="px-6 py-3 border-b border-zinc-100 bg-zinc-50/70 text-xs text-zinc-600 flex items-center justify-between">
            <span>Atelier Mitgliedsbereich</span>
            <button
              type="button"
              onClick={() => {
                setIsLoggedIn(true);
                setActiveTab('orders');
              }}
              className="text-zinc-900 font-semibold underline"
            >
              (Demo-Login aktivieren)
            </button>
          </div>
        )}

        {/* Drawer Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* TAB 1: Logged-in Orders Overview */}
          {isLoggedIn && activeTab === 'orders' && (
            <div className="space-y-6">
              <div className="p-4 bg-zinc-50 border border-zinc-100 flex items-center justify-between text-xs">
                <div>
                  <span className="text-zinc-400 block text-[10px] uppercase tracking-wider">
                    Angemeldet als
                  </span>
                  <span className="font-semibold text-zinc-950">{userName}</span>
                  <span className="text-zinc-500 block text-[11px]">{userEmail}</span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 font-medium">
                    Atelier VIP
                  </span>
                </div>
              </div>

              {/* Order Cards */}
              <div className="space-y-4">
                <span className="text-xs uppercase tracking-wider text-zinc-400 font-medium block">
                  Aktuelle Bestellübersicht
                </span>

                {sampleOrders.map((ord) => (
                  <div
                    key={ord.id}
                    className="border border-zinc-200 bg-white p-5 space-y-4 hover:border-zinc-400 transition-colors shadow-xs"
                  >
                    <div className="flex items-center justify-between border-b border-zinc-100 pb-3 text-xs">
                      <div>
                        <span className="font-mono text-zinc-950 font-semibold">
                          #{ord.id}
                        </span>
                        <span className="text-zinc-400 block text-[11px]">{ord.date}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-xs font-semibold text-zinc-950 tabular-nums">
                          {ord.price}
                        </span>
                        <span className="text-[10px] text-zinc-500 block">Kostenfreier Express</span>
                      </div>
                    </div>

                    <div className="space-y-1 text-xs">
                      <div className="font-medium text-zinc-950 text-sm font-editorial">
                        {ord.item}
                      </div>
                      <p className="text-zinc-500 text-[11px]">{ord.details}</p>
                      <div className="text-zinc-600 font-mono text-[11px] pt-1">
                        {ord.numberedPiece}
                      </div>
                    </div>

                    {/* Order Progress / Status */}
                    <div className="p-3 bg-zinc-50 border border-zinc-100 space-y-2 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="text-zinc-500">Status:</span>
                        <span className="font-medium text-zinc-950 flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5 text-zinc-700" />
                          <span>{ord.status}</span>
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-[11px] text-zinc-500 pt-1 border-t border-zinc-100">
                        <span>Lieferfenster:</span>
                        <span className="text-zinc-900 font-medium">{ord.deliveryWindow}</span>
                      </div>
                    </div>

                    <div className="pt-2 flex items-center justify-between text-[11px]">
                      <span className="text-zinc-400">{ord.tracking}</span>
                      <button
                        type="button"
                        onClick={() => alert(`Bestellnachweis für #${ord.id} wurde simuliert aufgerufen.`)}
                        className="text-zinc-950 font-semibold hover:underline"
                      >
                        Beleg einsehen →
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="p-4 border border-zinc-100 bg-white text-xs text-zinc-500 space-y-1">
                <div className="flex items-center gap-1.5 font-medium text-zinc-900">
                  <ShieldCheck className="w-4 h-4 text-zinc-700" />
                  <span>Atelier-Garantie</span>
                </div>
                <p className="text-[11px]">
                  Jedes Kleidungsstück beinhaltet lebenslange Formreparatur der Schulternähte und kostenlosen Größentausch bei Bedarf.
                </p>
              </div>
            </div>
          )}

          {/* TAB 2: VIP Passes & Drops */}
          {isLoggedIn && activeTab === 'vip' && (
            <div className="space-y-5">
              <div>
                <span className="text-xs uppercase tracking-wider text-zinc-400 font-medium block mb-1">
                  Exklusiver Launch-Zugang
                </span>
                <h4 className="text-lg font-light font-editorial text-zinc-950">
                  Deine hinterlegten Drop-Pässe
                </h4>
              </div>

              <div className="p-5 border border-zinc-200 bg-zinc-50 space-y-3">
                <div className="flex items-center justify-between text-xs text-zinc-400 uppercase tracking-widest border-b border-zinc-200 pb-2">
                  <span>VIP DROP TOKEN</span>
                  <span>{brandSettings.editionCode}</span>
                </div>
                <div>
                  <span className="text-[10px] uppercase text-zinc-400 block tracking-wider">
                    Gültig für 2h Vorab-Zugang
                  </span>
                  <span className="font-mono text-base font-bold text-zinc-950 tracking-wider">
                    VIP-ATELIER-01-9842
                  </span>
                </div>
                <p className="text-xs text-zinc-600 leading-relaxed font-light">
                  Dein Token ist aktiv für den Launch im {brandSettings.dropDate}. Du erhältst rechtzeitig vorab eine Benachrichtigung.
                </p>
              </div>

              <div className="p-4 border border-zinc-100 bg-white text-xs text-zinc-600 space-y-2">
                <div className="font-medium text-zinc-900">Vorgemerkte Silhouetten:</div>
                <ul className="space-y-1 text-zinc-500 text-[11px]">
                  <li>• Silhouette 02: Wide-Leg Pleated Trouser (Fitting benachrichtigen)</li>
                  <li>• Silhouette 03: Heavy Interlock Tee (Stofffreigabe benachrichtigen)</li>
                </ul>
              </div>
            </div>
          )}

          {/* TAB 3: Login / Registration Form */}
          {!isLoggedIn && (
            <div className="space-y-6">
              <div>
                <span className="text-xs uppercase tracking-wider text-zinc-400 font-medium block mb-1">
                  {isRegisterMode ? 'Neues Konto anlegen' : 'Willkommen zurück'}
                </span>
                <h3 className="text-2xl font-light font-editorial text-zinc-950">
                  {isRegisterMode ? 'Im Atelier registrieren' : 'Bei deinem Konto anmelden'}
                </h3>
                <p className="text-xs text-zinc-600 mt-1 font-light leading-relaxed">
                  Verwalte deine Vorbestellungen, verfolge den Fertigungsstatus deines {brandSettings.editionCode} Pullovers und erhalte VIP-Launch-Priorität.
                </p>
              </div>

              <form onSubmit={handleLoginSubmit} className="space-y-4 text-xs">
                <div>
                  <label className="block uppercase tracking-wider text-zinc-500 mb-1 font-medium">
                    E-Mail-Adresse
                  </label>
                  <div className="relative">
                    <input
                      type="email"
                      required
                      value={emailInput}
                      onChange={(e) => setEmailInput(e.target.value)}
                      placeholder="kunde@atelier-blanc.de"
                      className="w-full px-3 py-3 pl-9 border border-zinc-200 text-xs focus:border-zinc-950 focus:outline-none"
                    />
                    <Mail className="w-4 h-4 text-zinc-400 absolute left-3 top-3.5" />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="uppercase tracking-wider text-zinc-500 font-medium">
                      Passwort
                    </label>
                    {!isRegisterMode && (
                      <button
                        type="button"
                        onClick={() => alert('Passwort-Reset-Link wurde simuliert.')}
                        className="text-[11px] text-zinc-400 hover:text-zinc-950"
                      >
                        Vergessen?
                      </button>
                    )}
                  </div>
                  <div className="relative">
                    <input
                      type="password"
                      required
                      value={passwordInput}
                      onChange={(e) => setPasswordInput(e.target.value)}
                      placeholder="••••••••"
                      className="w-full px-3 py-3 pl-9 border border-zinc-200 text-xs focus:border-zinc-950 focus:outline-none"
                    />
                    <Lock className="w-4 h-4 text-zinc-400 absolute left-3 top-3.5" />
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full py-4 bg-zinc-950 hover:bg-zinc-800 text-white font-medium text-xs tracking-[0.18em] uppercase transition-colors"
                  >
                    {isRegisterMode ? 'Konto erstellen' : 'Anmelden'}
                  </button>
                </div>

                <div className="text-center pt-2">
                  <button
                    type="button"
                    onClick={() => setIsRegisterMode(!isRegisterMode)}
                    className="text-xs text-zinc-500 hover:text-zinc-950"
                  >
                    {isRegisterMode
                      ? 'Bereits registriert? Hier anmelden'
                      : 'Noch kein Atelier-Konto? Jetzt registrieren'}
                  </button>
                </div>
              </form>

              {/* Quick Demo Test Access */}
              <div className="p-4 bg-zinc-50 border border-zinc-100 text-xs space-y-2">
                <span className="font-semibold text-zinc-900 block">Schnelltest für die Vorschau:</span>
                <p className="text-zinc-500 text-[11px]">
                  Klicke auf den Button unten, um dich sofort als Beispielkunde mit aktiver Pullover-Bestellung einzuloggen.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setIsLoggedIn(true);
                    setActiveTab('orders');
                  }}
                  className="w-full py-2 bg-white border border-zinc-300 text-zinc-800 hover:border-zinc-950 font-medium transition-colors"
                >
                  Als Beispiel-Kunde einloggen & Bestellung ansehen
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-zinc-100 bg-white text-xs text-zinc-400 flex items-center justify-between">
          <span>{brandSettings.brandName} Atelier</span>
          <span>Sichere 256-Bit SSL Verschlüsselung</span>
        </div>
      </div>
    </div>
  );
};
