import React from 'react';
import { X } from 'lucide-react';
import { BrandSettings } from '../types';

interface LegalModalProps {
  isOpen: boolean;
  onClose: () => void;
  legalType: string | null;
  brandSettings: BrandSettings;
}

export const LegalModal: React.FC<LegalModalProps> = ({
  isOpen,
  onClose,
  legalType,
  brandSettings,
}) => {
  if (!isOpen || !legalType) return null;

  const getLegalContent = (type: string) => {
    switch (type) {
      case 'Imprint':
        return {
          title: 'Imprint',
          content: `${brandSettings.brandName} Maison\nAngaben gemäß § 5 TMG / European E-Commerce Regulations:\n\nVerantwortlich für den Inhalt:\nGeschäftsführung Atelier Maison\nKontakt: contact@atelierblanc.example\nRegistergericht: Amtsgericht Berlin / Charlottenburg\nUmsatzsteuer-ID: DE999999999`,
        };
      case 'Privacy Policy':
        return {
          title: 'Privacy Policy',
          content: `Datenschutzerklärung\n\n1. Datenschutz auf einen Blick\nDie folgenden Hinweise geben einen einfachen Überblick darüber, was mit Ihren personenbezogenen Daten passiert, wenn Sie unsere Website besuchen. Personenbezogene Daten sind alle Daten, mit denen Sie persönlich identifiziert werden können.\n\n2. Datenerfassung auf unserer Website\nDie Datenerfassung auf dieser Website erfolgt durch den Websitebetreiber. Dessen Kontaktdaten können Sie dem Imprint entnehmen.\n\n3. Wofür nutzen wir Ihre Daten?\nEin Teil der Daten wird erhoben, um eine fehlerfreie Bereitstellung der Website zu gewährleisten. Andere Daten können zur Analyse Ihres Nutzerverhaltens verwendet werden.`,
        };
      case 'Terms of Service':
        return {
          title: 'Terms of Service',
          content: `Allgemeine Geschäftsbedingungen (AGB)\n\n§ 1 Geltungsbereich\nFür alle Geschäftsbeziehungen zwischen ${brandSettings.brandName} und dem Kunden gelten ausschließlich die nachfolgenden Allgemeinen Geschäftsbedingungen in ihrer zum Zeitpunkt der Bestellung gültigen Fassung.\n\n§ 2 Vertragsschluss\nDie Darstellung der Produkte im Online-Shop stellt kein rechtlich bindendes Angebot, sondern einen unverbindlichen Online-Katalog dar.\n\n§ 3 Preise und Versand\nAlle Preise verstehen sich inklusive der gesetzlichen Mehrwertsteuer zuzüglich anfallender Versandkosten.`,
        };
      case 'Refund Policy':
        return {
          title: 'Refund Policy',
          content: `Widerrufsbelehrung & Rückgaberecht\n\nSie haben das Recht, binnen vierzehn Tagen ohne Angabe von Gründen diesen Vertrag zu widerrufen.\n\nDie Widerrufsfrist beträgt vierzehn Tage ab dem Tag, an dem Sie oder ein von Ihnen benannter Dritter, der nicht der Beförderer ist, die Waren in Besitz genommen haben.\n\nUm Ihr Widerrufsrecht auszuüben, müssen Sie uns mittels einer eindeutigen Erklärung über Ihren Entschluss informieren.`,
        };
      case 'Accessibility':
        return {
          title: 'Accessibility Statement',
          content: `${brandSettings.brandName} ist bemüht, die Website in Einklang mit den nationalen Rechtsvorschriften zur Umsetzung der Richtlinie (EU) 2019/882 des Europäischen Parlaments und des Rates barrierefrei zugänglich zu machen.\n\nWir arbeiten kontinuierlich daran, die Benutzererfahrung für alle Menschen zu verbessern und die entsprechenden Barrierefreiheitsstandards (WCAG 2.1 AA) anzuwenden.`,
        };
      case 'Legal Warranty':
        return {
          title: 'Legal Warranty',
          content: `Gesetzliche Gewährleistung\n\nFür unsere Waren bestehen die gesetzlichen Mängelhaftungsrechte.\n\nSollten gelieferte Artikel offensichtliche Material- oder Herstellungsfehler aufweisen (inklusive Transportschäden), reklamieren Sie bitte solche Fehler sofort gegenüber uns. Die Gewährleistungsfrist beträgt 2 Jahre ab Übergabe der Ware.`,
        };
      case 'Contact':
        return {
          title: 'Contact',
          content: `Get in Touch\n\nAtelier Client Services\nEmail: contact@atelierblanc.example\nPhone: +49 (0) 30 00000000\nSupport Hours: Monday - Friday, 10:00 - 18:00 CET`,
        };
      case 'Return':
        return {
          title: 'Returns & Exchanges',
          content: `Returns & Exchanges\n\nWe offer a 14-day return policy for all unworn items in their original packaging with tags attached.\n\nTo initiate a return, please contact our support team at contact@atelierblanc.example with your order number. You will receive a pre-paid return shipping label via email.`,
        };
      default:
        return { title: type, content: 'Informationen folgen in Kürze.' };
    }
  };

  const { title, content } = getLegalContent(legalType);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="w-full max-w-2xl bg-white p-8 shadow-2xl relative border border-zinc-200 space-y-6 max-h-[85vh] overflow-y-auto text-zinc-900 font-sans-brand">
        <div className="flex items-center justify-between border-b border-zinc-100 pb-4">
          <h2 className="text-base font-bold uppercase tracking-[0.2em] text-zinc-950">
            {title}
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="p-1 text-zinc-400 hover:text-zinc-950 transition-colors"
            aria-label="Schließen"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="prose prose-zinc text-xs sm:text-sm leading-relaxed whitespace-pre-line text-zinc-700">
          {content}
        </div>

        <div className="pt-4 border-t border-zinc-100 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-6 py-2.5 bg-zinc-950 text-white text-xs uppercase tracking-widest font-medium hover:bg-zinc-800 transition-colors cursor-pointer rounded-sm"
          >
            Schließen
          </button>
        </div>
      </div>
    </div>
  );
};
