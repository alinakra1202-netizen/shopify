import React, { useState } from 'react';
import {
  Ruler,
  Check,
  Sparkles,
  ShoppingBag,
  ArrowRight,
  Maximize2,
  RefreshCw,
  Info,
} from 'lucide-react';
import { ProductDetailItem, ProductColorway, ProductSize, BrandSettings } from '../types';

interface ProductDetailProps {
  product: ProductDetailItem;
  brandSettings: BrandSettings;
  onAddToCart: (size: ProductSize, colorway: ProductColorway) => void;
  onOpenSizeGuide: () => void;
  onOpenDropModal: () => void;
}

export const ProductDetail: React.FC<ProductDetailProps> = ({
  product,
  brandSettings,
  onAddToCart,
  onOpenSizeGuide,
  onOpenDropModal,
}) => {
  const [selectedColor, setSelectedColor] = useState<ProductColorway>(product.colorways[0]);
  const [selectedSize, setSelectedSize] = useState<ProductSize>('M');
  const [activeImageKey, setActiveImageKey] = useState<'hero' | 'lookbook' | 'detail' | 'atelier'>('hero');
  const [activeTab, setActiveTab] = useState<'details' | 'material' | 'fit' | 'care'>('details');
  const [isZoomed, setIsZoomed] = useState<boolean>(false);

  const sizes: ProductSize[] = ['XS', 'S', 'M', 'L', 'XL'];

  const imageMap = {
    hero: {
      url: product.images.hero,
      title: 'Studio Silhouette',
      caption: 'Vorderansicht in natürlichem Nordlicht',
    },
    lookbook: {
      url: product.images.lookbook,
      title: 'Editorial Styling',
      caption: 'Ganzkörper-Fall mit Tailored Trouser',
    },
    detail: {
      url: product.images.detail,
      title: '600 GSM Makro-Gewebe',
      caption: 'Doppelripp-Kragen und Maschendichte',
    },
    atelier: {
      url: product.images.atelier,
      title: 'Atelier Entwicklung',
      caption: 'Schnittmuster & Drapierung am Mannequin',
    },
  };

  const handleBuyOrReserve = () => {
    onAddToCart(selectedSize, selectedColor);
  };

  return (
    <section id="edition-01" className="bg-white py-16 sm:py-24 border-b border-zinc-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="mb-12 max-w-3xl">
          <div className="flex items-center gap-2 text-xs tracking-[0.2em] uppercase text-zinc-400 mb-2">
            <span>{brandSettings.editionCode}</span>
            <span aria-hidden="true">/</span>
            <span>Debüt Pullover</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-light text-zinc-950 tracking-tight font-editorial">
            {product.name}
          </h2>
          <p className="text-zinc-500 text-sm sm:text-base mt-2 font-light">
            {product.subtitle} · Entwickelt ohne Kompromisse bei Haptik und Stand.
          </p>
        </div>

        {/* 2-Column Product Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-start">
          {/* Left: Gallery & Zoomable View */}
          <div className="lg:col-span-7 space-y-4">
            {/* Main Stage Image */}
            <div className="relative bg-zinc-50 border border-zinc-200 overflow-hidden group">
              <img
                src={imageMap[activeImageKey].url}
                alt={imageMap[activeImageKey].title}
                referrerPolicy="no-referrer"
                className={`w-full h-[450px] sm:h-[580px] object-cover transition-transform duration-500 ${
                  isZoomed ? 'scale-125 cursor-zoom-out' : 'group-hover:scale-[1.03] cursor-zoom-in'
                }`}
                onClick={() => setIsZoomed(!isZoomed)}
              />

              <div className="absolute top-4 right-4 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsZoomed(!isZoomed)}
                  className="p-2 bg-white/90 backdrop-blur-sm text-zinc-700 hover:text-zinc-950 border border-zinc-200 transition-colors"
                  title={isZoomed ? 'Herauszoomen' : 'Detail heranzoomen'}
                >
                  <Maximize2 className="w-4 h-4" />
                </button>
              </div>

              {/* Quiet caption bar */}
              <div className="absolute bottom-3 left-3 bg-white/95 px-3 py-1.5 border border-zinc-100 text-xs text-zinc-600 flex items-center gap-2">
                <span className="font-medium text-zinc-900">{imageMap[activeImageKey].title}</span>
                <span aria-hidden="true">·</span>
                <span className="text-zinc-500">{imageMap[activeImageKey].caption}</span>
              </div>
            </div>

            {/* 4 Thumbnail Switchers */}
            <div className="grid grid-cols-4 gap-3">
              {(Object.keys(imageMap) as Array<keyof typeof imageMap>).map((key) => {
                const item = imageMap[key];
                const isActive = activeImageKey === key;
                return (
                  <button
                    key={key}
                    type="button"
                    onClick={() => {
                      setActiveImageKey(key);
                      setIsZoomed(false);
                    }}
                    className={`relative p-1 border text-left transition-all ${
                      isActive ? 'border-zinc-950 bg-white ring-1 ring-zinc-950' : 'border-zinc-200 hover:border-zinc-400 bg-zinc-50'
                    }`}
                  >
                    <img
                      src={item.url}
                      alt={item.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-16 sm:h-20 object-cover"
                    />
                    <span className="block mt-1 text-[10px] tracking-wider uppercase font-medium text-zinc-600 truncate">
                      {item.title}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right: Contiguous Purchase Module */}
          <div className="lg:col-span-5 flex flex-col space-y-7 lg:sticky lg:top-28">
            {/* Header & Price */}
            <div className="pb-5 border-b border-zinc-100">
              <div className="flex items-baseline justify-between">
                <span className="text-3xl font-light text-zinc-950 font-editorial tabular-nums">
                  {brandSettings.price} {brandSettings.currency}
                </span>
                <span className="text-xs uppercase tracking-widest text-zinc-500">
                  Inkl. MwSt. · Kostenloser EU-Versand
                </span>
              </div>
              <p className="text-xs text-zinc-500 mt-2">
                Artikel-Nr.: <span className="font-mono text-zinc-700">{product.sku}</span> · Drop-Edition 01
              </p>
            </div>

            {/* Colorway Selection */}
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs tracking-wider uppercase">
                <span className="text-zinc-500">Farbton</span>
                <span className="font-medium text-zinc-900">{selectedColor.name} ({selectedColor.label})</span>
              </div>
              <div className="flex items-center gap-3">
                {product.colorways.map((c) => {
                  const isSelected = selectedColor.id === c.id;
                  return (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => setSelectedColor(c)}
                      className={`group relative flex items-center gap-2 px-3 py-2 border transition-all text-left ${
                        isSelected
                          ? 'border-zinc-950 bg-white ring-1 ring-zinc-950'
                          : 'border-zinc-200 hover:border-zinc-400 bg-white'
                      }`}
                    >
                      <span
                        className="w-4 h-4 rounded-full border shrink-0"
                        style={{
                          backgroundColor: c.hex,
                          borderColor: c.borderHex || '#d4d4d8',
                        }}
                      />
                      <span className="text-xs font-medium text-zinc-900 whitespace-nowrap">
                        {c.name}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Size Selector */}
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs tracking-wider uppercase">
                <span className="text-zinc-500">Größe (Unisex Boxy Fit)</span>
                <button
                  type="button"
                  onClick={onOpenSizeGuide}
                  className="flex items-center gap-1.5 text-zinc-900 font-semibold hover:underline"
                >
                  <Ruler className="w-3.5 h-3.5" />
                  <span>Größentabelle & Maße</span>
                </button>
              </div>

              <div className="grid grid-cols-5 gap-2">
                {sizes.map((s) => {
                  const isSelected = selectedSize === s;
                  return (
                    <button
                      key={s}
                      type="button"
                      onClick={() => setSelectedSize(s)}
                      className={`py-3 text-xs font-semibold tracking-wider transition-all border ${
                        isSelected
                          ? 'bg-zinc-950 text-white border-zinc-950 shadow-sm'
                          : 'bg-white text-zinc-800 border-zinc-200 hover:border-zinc-950 hover:bg-zinc-50'
                      }`}
                    >
                      {s}
                    </button>
                  );
                })}
              </div>

              {/* Sizing hint */}
              <p className="text-xs text-zinc-500 font-light flex items-start gap-1.5 pt-1">
                <Info className="w-3.5 h-3.5 text-zinc-400 shrink-0 mt-0.5" />
                <span>
                  Boxy Schnitt. Geeignet für deine reguläre Konfektionsgröße bei normalem Sitz. Model trägt Größe L bei 186 cm.
                </span>
              </p>
            </div>

            {/* Primary Action Buttons */}
            <div className="space-y-3 pt-2">
              <button
                type="button"
                onClick={handleBuyOrReserve}
                className="w-full py-4 px-6 bg-zinc-950 hover:bg-zinc-800 text-white font-medium text-xs tracking-[0.18em] uppercase transition-colors flex items-center justify-center gap-2 shadow-sm"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>In die Vorbestellung legen ({selectedSize} · {selectedColor.name})</span>
              </button>

              <button
                type="button"
                onClick={onOpenDropModal}
                className="w-full py-3 px-6 bg-white hover:bg-zinc-50 border border-zinc-200 text-zinc-900 font-medium text-xs tracking-[0.16em] uppercase transition-colors flex items-center justify-center gap-2"
              >
                <span>Drop Warteliste mit 2h Vorab Zugang beitreten</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Allocation assurance */}
            <div className="p-4 bg-zinc-50/80 border border-zinc-100 text-xs text-zinc-600 space-y-1">
              <div className="flex items-center justify-between text-zinc-900 font-medium">
                <span>Atelier Batch 01 Status:</span>
                <span className="tabular-nums">150 Stück limitiert</span>
              </div>
              <p className="text-[11px] text-zinc-500">
                Jedes Exemplar wird mit einer eingewebten Atelier-Nummerierung und Echtheitszertifikat geliefert.
              </p>
            </div>

            {/* Technical Detail Tabs */}
            <div className="pt-4 border-t border-zinc-100">
              <div className="flex border-b border-zinc-100 gap-6 text-xs uppercase tracking-wider font-medium text-zinc-500">
                <button
                  type="button"
                  onClick={() => setActiveTab('details')}
                  className={`pb-2 transition-colors ${
                    activeTab === 'details' ? 'border-b-2 border-zinc-950 text-zinc-950' : 'hover:text-zinc-900'
                  }`}
                >
                  Details
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('material')}
                  className={`pb-2 transition-colors ${
                    activeTab === 'material' ? 'border-b-2 border-zinc-950 text-zinc-950' : 'hover:text-zinc-900'
                  }`}
                >
                  Material (600 GSM)
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('fit')}
                  className={`pb-2 transition-colors ${
                    activeTab === 'fit' ? 'border-b-2 border-zinc-950 text-zinc-950' : 'hover:text-zinc-900'
                  }`}
                >
                  Passform & Schnitt
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('care')}
                  className={`pb-2 transition-colors ${
                    activeTab === 'care' ? 'border-b-2 border-zinc-950 text-zinc-950' : 'hover:text-zinc-900'
                  }`}
                >
                  Pflege
                </button>
              </div>

              <div className="pt-4 text-xs text-zinc-600 leading-relaxed font-light">
                {activeTab === 'details' && (
                  <ul className="space-y-2">
                    {product.specs.map((spec, idx) => (
                      <li key={idx} className="flex justify-between py-1 border-b border-zinc-50">
                        <span className="text-zinc-400">{spec.label}</span>
                        <span className="text-zinc-900 font-medium text-right">{spec.value}</span>
                      </li>
                    ))}
                  </ul>
                )}

                {activeTab === 'material' && (
                  <div className="space-y-2">
                    <p>
                      <strong>Zusammensetzung:</strong> {product.composition}
                    </p>
                    <p>
                      <strong>Textilgewicht:</strong> 600 GSM (Grams per Square Meter). Zum Vergleich: Handelsübliche Standard-Pullover liegen bei 280–350 GSM. Dieses Gewicht verleiht dem Pullover einen architektonischen, faltenfreien Stand.
                    </p>
                    <p>
                      <strong>Herkunft:</strong> {product.origin}
                    </p>
                  </div>
                )}

                {activeTab === 'fit' && (
                  <div className="space-y-2">
                    <p>
                      <strong>Schnittführung:</strong> Zeitgenössischer Boxy Fit. Die Schulternaht ist um 5 cm nach unten versetzt, um eine entspannte Silhouette zu kreieren.
                    </p>
                    <p>
                      <strong>Länge:</strong> Leicht verkürzter Rumpf (Cropped Waistline), damit der Pullover nicht bauscht und perfekt mit Tailored Trousers oder Denim harmoniert.
                    </p>
                  </div>
                )}

                {activeTab === 'care' && (
                  <div className="space-y-2">
                    <p>• Kaltwäsche oder 30°C Wollprogramm im Wäschesack.</p>
                    <p>• Nur flüssiges Wollwaschmittel ohne optische Aufheller verwenden.</p>
                    <p>• Nicht im Wäschetrockner trocknen. Liegend auf einem Handtuch in Form ziehen.</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
