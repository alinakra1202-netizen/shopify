import React, { useState } from 'react';
import { BrandSettings } from '../types';
import { BrandLogo } from './BrandLogo';
import { Check, Instagram } from 'lucide-react';

interface FooterProps {
  brandSettings: BrandSettings;
  onOpenDropModal: () => void;
  onOpenSizeGuide: () => void;
  onOpenCustomizer: () => void;
  onOpenLegal: (type: string) => void;
  logoUrl?: string | null;
}

export const Footer: React.FC<FooterProps> = ({ onOpenLegal, logoUrl }) => {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    setSubmitted(true);
  };

  const legalPages = [
    'Imprint',
    'Privacy Policy',
    'Terms of Service',
    'Refund Policy',
    'Accessibility',
    'Legal Warranty',
  ];

  const servicePages = [
    'Contact',
    'Return',
  ];

  return (
    <footer className="bg-zinc-950 py-12 sm:py-16 text-zinc-100">
      <div className="max-w-xl mx-auto px-4 sm:px-6 text-center sm:text-left space-y-12">
        {/* Centered Logo */}
        <div className="flex justify-center sm:justify-start">
          <BrandLogo logoUrl={logoUrl} className="h-8 w-auto brightness-0 invert" />
        </div>

        {/* Newsletter Slogan & Form */}
        <div className="space-y-4 text-center sm:text-left">
          <p className="text-xs sm:text-sm font-light uppercase tracking-[0.2em] text-zinc-300 font-sans-brand">
            Be the first. Wear the latest. Sign up now for the newsletter.
          </p>

          {submitted ? (
            <div className="flex items-center justify-center sm:justify-start gap-2 text-emerald-400 text-xs uppercase tracking-wider py-2">
              <Check className="w-4 h-4" />
              <span>Erfolgreich angemeldet. Willkommen.</span>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="flex items-center max-w-md border border-zinc-700 rounded-sm bg-zinc-900/80 overflow-hidden shadow-sm">
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Deine E-Mail-Adresse..."
                className="w-full bg-transparent text-xs sm:text-sm text-white placeholder-zinc-500 px-4 py-3 focus:outline-none tracking-wider"
              />
              <button
                type="submit"
                className="px-5 py-3 bg-white text-zinc-950 hover:bg-zinc-200 transition-colors cursor-pointer shrink-0 text-xs font-semibold uppercase tracking-wider"
                aria-label="Newsletter abonnieren"
              >
                Anmelden
              </button>
            </form>
          )}
        </div>

        {/* Legal & Service Sections Side-by-Side with Socials under Service */}
        <div className="grid grid-cols-2 gap-8 text-left">
          {/* Legal Column */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-[0.25em] text-zinc-400 font-sans-brand">
              Legal
            </h3>
            <div className="flex flex-col items-start gap-2">
              {legalPages.map((page) => (
                <button
                  key={page}
                  type="button"
                  onClick={() => onOpenLegal(page)}
                  className="text-[11px] uppercase tracking-wider text-zinc-400 hover:text-white transition-colors cursor-pointer font-light text-left"
                >
                  {page}
                </button>
              ))}
            </div>
          </div>

          {/* Service Column with Socials underneath */}
          <div className="space-y-6">
            <div className="space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-[0.25em] text-zinc-400 font-sans-brand">
                Service
              </h3>
              <div className="flex flex-col items-start gap-2">
                {servicePages.map((page) => (
                  <button
                    key={page}
                    type="button"
                    onClick={() => onOpenLegal(page)}
                    className="text-[11px] uppercase tracking-wider text-zinc-400 hover:text-white transition-colors cursor-pointer font-light text-left"
                  >
                    {page}
                  </button>
                ))}
              </div>
            </div>

            {/* Socials underneath Service */}
            <div className="space-y-3 pt-2">
              <h3 className="text-xs font-bold uppercase tracking-[0.25em] text-zinc-400 font-sans-brand">
                Socials
              </h3>
              <div className="flex items-center justify-start gap-3">
                <a
                  href="https://instagram.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-1 text-zinc-400 hover:text-white transition-colors"
                  aria-label="Instagram"
                >
                  <Instagram className="w-5 h-5 stroke-[1.75]" />
                </a>
                <a
                  href="https://tiktok.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-1 text-zinc-400 hover:text-white transition-colors"
                  aria-label="TikTok"
                >
                  <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                    <path d="M19.589 6.686a4.793 4.793 0 0 1-3.77-4.245V2h-3.445v13.672a2.896 2.896 0 0 1-5.01 1.953 2.892 2.892 0 0 1 1.452-4.925c.12-.022.242-.033.365-.033v-3.46a6.34 6.34 0 0 0-.584.053 6.336 6.336 0 0 0-5.836 6.315 6.338 6.338 0 0 0 6.338 6.338 6.34 6.34 0 0 0 6.338-6.338V8.75a8.217 8.217 0 0 0 4.767 1.524V6.852a4.8 4.8 0 0 1-1.002-.166z"/>
                  </svg>
                </a>
                <a
                  href="https://whatsapp.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-1 text-zinc-400 hover:text-white transition-colors"
                  aria-label="WhatsApp"
                >
                  <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                    <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/>
                  </svg>
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Very Bottom Section: Secure Payments */}
        <div className="flex flex-col items-center justify-center text-center space-y-6 pt-6">
          {/* Secure Payments */}
          <div className="space-y-2.5 pt-2">
            <h4 className="text-[10px] font-bold uppercase tracking-[0.3em] text-zinc-400">
              Secure Payments
            </h4>
            <div className="flex flex-wrap items-center justify-center gap-2">
              {/* Klarna Badge */}
              <div className="w-15 h-6.5 bg-[#FFB3C7] rounded-xs flex items-center justify-center shadow-xs" title="Klarna">
                <span className="text-[9px] font-bold font-sans text-zinc-950 tracking-tighter">Klarna.</span>
              </div>

              {/* PayPal Logo */}
              <div className="w-15 h-6.5 bg-zinc-900 border border-zinc-800 rounded-xs flex items-center justify-center shadow-xs" title="PayPal">
                <span className="text-[9px] font-extrabold italic font-sans text-[#003087] tracking-tighter">Pay<span className="text-[#0079C1]">Pal</span></span>
              </div>

              {/* Apple Pay Logo */}
              <div className="w-15 h-6.5 bg-black border border-zinc-800 rounded-xs flex items-center justify-center shadow-xs" title="Apple Pay">
                <span className="text-[9px] font-medium font-sans text-white tracking-tight flex items-center gap-0.5">
                  <svg className="w-3 h-3 fill-current text-white" viewBox="0 0 24 24">
                    <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 5.75c.61-.75 1.03-1.8 0.92-2.85-.9.04-1.99.6-2.63 1.35-.57.65-1.07 1.71-0.94 2.74 1.01.08 2.04-.49 2.65-1.24z"/>
                  </svg>
                  <span className="font-bold">Pay</span>
                </span>
              </div>

              {/* Google Pay Logo */}
              <div className="w-15 h-6.5 bg-zinc-900 border border-zinc-800 rounded-xs flex items-center justify-center shadow-xs" title="Google Pay">
                <div className="flex items-center gap-0.5">
                  <svg className="w-3 h-3" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z"/>
                    <path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.13 0-5.78-2.11-6.73-4.96H1.2v3.15C3.21 21.32 7.29 24 12 24z"/>
                    <path fill="#FBBC05" d="M5.27 14.24c-.25-.72-.38-1.49-.38-2.24s.13-1.52.38-2.24V6.6H1.2C.43 8.14 0 9.89 0 12s.43 3.86 1.2 5.4l4.07-3.16z"/>
                    <path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.29 0 3.21 2.68 1.2 6.6l4.07 3.15c.95-2.85 3.6-4.96 6.73-4.96z"/>
                  </svg>
                  <span className="text-[9px] font-bold font-sans text-white tracking-tight">Pay</span>
                </div>
              </div>

              {/* Mastercard Logo */}
              <div className="w-15 h-6.5 bg-zinc-900 border border-zinc-800 rounded-xs flex items-center justify-center shadow-xs" title="Mastercard">
                <div className="flex items-center -space-x-1">
                  <div className="w-3 h-3 rounded-full bg-[#EB001B] opacity-90" />
                  <div className="w-3 h-3 rounded-full bg-[#F79E1B] opacity-90" />
                </div>
              </div>

              {/* Visa Logo */}
              <div className="w-15 h-6.5 bg-zinc-900 border border-zinc-800 rounded-xs flex items-center justify-center shadow-xs" title="Visa">
                <span className="text-[9px] font-black italic font-sans text-[#1A1F71] tracking-tighter bg-white px-1 py-0.2 rounded-2xs">VISA</span>
              </div>
            </div>
          </div>

          {/* Withdraw from contract button */}
          <div className="pt-2 flex justify-center">
            <button
              type="button"
              onClick={() => onOpenLegal('Refund Policy')}
              className="px-4 py-2 bg-zinc-900 border border-zinc-800 text-[11px] uppercase tracking-widest text-zinc-300 hover:text-white hover:border-zinc-700 transition-colors cursor-pointer rounded-sm"
            >
              Withdraw from contract
            </button>
          </div>

          {/* Copyright & Cookie Settings at the very bottom */}
          <div className="pt-2 text-center text-[10px] uppercase tracking-wider text-zinc-500 font-mono space-y-1">
            <div>© 2026 Noar Ks. All rights reserved.</div>
            <div>
              <button
                type="button"
                onClick={() => alert('Cookie Settings opened.')}
                className="hover:text-zinc-300 transition-colors underline cursor-pointer"
              >
                Cookie Settings
              </button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};
