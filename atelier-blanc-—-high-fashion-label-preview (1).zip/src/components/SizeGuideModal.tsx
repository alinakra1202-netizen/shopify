import React, { useState } from 'react';
import { X, Ruler, Check, HelpCircle } from 'lucide-react';
import { ProductSize } from '../types';

interface SizeGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectSize?: (size: ProductSize) => void;
}

export const SizeGuideModal: React.FC<SizeGuideModalProps> = ({
  isOpen,
  onClose,
  onSelectSize,
}) => {
  const [unit, setUnit] = useState<'cm' | 'in'>('cm');
  const [userHeight, setUserHeight] = useState<number>(180);
  const [userWeight, setUserWeight] = useState<number>(75);
  const [fitPreference, setFitPreference] = useState<'regular' | 'boxy' | 'extreme'>('boxy');

  if (!isOpen) return null;

  // Chart data in cm
  const sizeChartCm = [
    { size: 'XS', chest: 60, length: 64, sleeve: 57, shoulder: 58 },
    { size: 'S', chest: 63, length: 66, sleeve: 59, shoulder: 60 },
    { size: 'M', chest: 66, length: 68, sleeve: 61, shoulder: 62 },
    { size: 'L', chest: 69, length: 70, sleeve: 63, shoulder: 64 },
    { size: 'XL', chest: 72, length: 72, sleeve: 65, shoulder: 66 },
  ];

  // Helper conversion to inches
  const convert = (cmVal: number) => {
    if (unit === 'cm') return `${cmVal} cm`;
    return `${(cmVal / 2.54).toFixed(1)}″`;
  };

  // Simple sizing logic
  const calculateRecommendedSize = (): ProductSize => {
    let score = (userHeight - 160) * 0.4 + (userWeight - 55) * 0.6;
    if (fitPreference === 'extreme') score += 15;
    if (fitPreference === 'regular') score -= 10;

    if (score < 15) return 'XS';
    if (score < 25) return 'S';
    if (score < 38) return 'M';
    if (score < 50) return 'L';
    return 'XL';
  };

  const recommendedSize = calculateRecommendedSize();

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white border border-zinc-200 max-w-2xl w-full p-6 sm:p-8 relative max-h-[90vh] overflow-y-auto shadow-2xl">
        <button
          type="button"
          onClick={onClose}
          className="absolute top-5 right-5 text-zinc-400 hover:text-zinc-900 transition-colors"
          aria-label="Schließen"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-zinc-400 mb-2">
          <Ruler className="w-3.5 h-3.5" />
          <span>Passform-Labor</span>
        </div>

        <h3 className="text-2xl font-light text-zinc-950 font-editorial">
          Größentabelle & Schnitt-Empfehlung
        </h3>
        <p className="text-xs text-zinc-600 mt-1 font-light">
          Der Boxy Knit verfügt über überschnittene Schultern und eine verkürzte Rumpflänge für eine monolithische Silhouette.
        </p>

        {/* Unit Selector */}
        <div className="mt-6 flex items-center justify-between border-b border-zinc-100 pb-3">
          <span className="text-xs uppercase tracking-wider text-zinc-500 font-medium">
            Exakte Maße des Kleidungsstücks (flach liegend)
          </span>
          <div className="flex items-center gap-1 bg-zinc-100 p-0.5 rounded-sm">
            <button
              type="button"
              onClick={() => setUnit('cm')}
              className={`px-2.5 py-1 text-xs font-medium transition-colors ${
                unit === 'cm' ? 'bg-white text-zinc-900 shadow-xs' : 'text-zinc-600 hover:text-zinc-900'
              }`}
            >
              Zentimeter (cm)
            </button>
            <button
              type="button"
              onClick={() => setUnit('in')}
              className={`px-2.5 py-1 text-xs font-medium transition-colors ${
                unit === 'in' ? 'bg-white text-zinc-900 shadow-xs' : 'text-zinc-600 hover:text-zinc-900'
              }`}
            >
              Inches (in)
            </button>
          </div>
        </div>

        {/* Table */}
        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className="border-b border-zinc-200 text-zinc-500 uppercase tracking-wider text-[11px]">
                <th className="py-2.5 font-medium">Größe</th>
                <th className="py-2.5 font-medium">1/2 Brustweite</th>
                <th className="py-2.5 font-medium">Rumpflänge</th>
                <th className="py-2.5 font-medium">Schulterbreite</th>
                <th className="py-2.5 font-medium">Ärmellänge</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100">
              {sizeChartCm.map((row) => (
                <tr
                  key={row.size}
                  className={row.size === recommendedSize ? 'bg-zinc-50 font-medium' : 'text-zinc-700'}
                >
                  <td className="py-3 font-semibold text-zinc-900 flex items-center gap-1.5">
                    <span>{row.size}</span>
                    {row.size === recommendedSize && (
                      <span className="text-[10px] bg-zinc-900 text-white px-1.5 py-0.2 tracking-wider uppercase font-normal">
                        Empfohlen
                      </span>
                    )}
                  </td>
                  <td className="py-3 tabular-nums">{convert(row.chest)}</td>
                  <td className="py-3 tabular-nums">{convert(row.length)}</td>
                  <td className="py-3 tabular-nums">{convert(row.shoulder)}</td>
                  <td className="py-3 tabular-nums">{convert(row.sleeve)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Interactive Fit Advisor Widget */}
        <div className="mt-8 p-5 bg-zinc-50 border border-zinc-200 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs uppercase tracking-wider font-semibold text-zinc-900">
              Persönlicher Größenberater
            </span>
            <span className="text-xs text-zinc-500">Live-Berechnung</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="block text-zinc-500 mb-1">Körpergröße ({userHeight} cm)</label>
              <input
                type="range"
                min={155}
                max={205}
                value={userHeight}
                onChange={(e) => setUserHeight(Number(e.target.value))}
                className="w-full accent-zinc-950 cursor-pointer"
              />
            </div>
            <div>
              <label className="block text-zinc-500 mb-1">Körpergewicht ({userWeight} kg)</label>
              <input
                type="range"
                min={45}
                max={120}
                value={userWeight}
                onChange={(e) => setUserWeight(Number(e.target.value))}
                className="w-full accent-zinc-950 cursor-pointer"
              />
            </div>
            <div>
              <label className="block text-zinc-500 mb-1">Gewünschter Fit</label>
              <select
                value={fitPreference}
                onChange={(e) => setFitPreference(e.target.value as any)}
                className="w-full p-2 bg-white border border-zinc-200 text-xs"
              >
                <option value="regular">Klassischer / Moderater Sitz</option>
                <option value="boxy">Design-Intention: Boxy Oversized</option>
                <option value="extreme">Extrem Oversized Statement</option>
              </select>
            </div>
          </div>

          <div className="pt-3 border-t border-zinc-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div className="text-xs text-zinc-700">
              Geeignet für deine Maße:{' '}
              <strong className="text-sm font-bold text-zinc-950">Größe {recommendedSize}</strong>
            </div>

            {onSelectSize && (
              <button
                type="button"
                onClick={() => {
                  onSelectSize(recommendedSize);
                  onClose();
                }}
                className="px-4 py-2 bg-zinc-950 text-white text-xs uppercase tracking-wider font-medium hover:bg-zinc-800 transition-colors"
              >
                Größe {recommendedSize} auswählen
              </button>
            )}
          </div>
        </div>

        {/* Model Spec Note */}
        <div className="mt-5 text-[11px] text-zinc-500 border-t border-zinc-100 pt-3">
          <strong>Referenz:</strong> Unser Kampagnen-Model ist 186 cm groß, wiegt 76 kg und trägt auf allen Fotos Größe L für den charakteristischen Runway-Fall.
        </div>
      </div>
    </div>
  );
};
