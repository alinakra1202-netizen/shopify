import React, { useState } from 'react';
import { X, CheckCircle2, Copy, Check, Sparkles, Lock } from 'lucide-react';
import { ProductSize, BrandSettings } from '../types';

interface DropAccessModalProps {
  isOpen: boolean;
  onClose: () => void;
  brandSettings: BrandSettings;
}

export const DropAccessModal: React.FC<DropAccessModalProps> = ({
  isOpen,
  onClose,
  brandSettings,
}) => {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [sizePreference, setSizePreference] = useState<ProductSize>('M');
  const [colorPreference, setColorPreference] = useState('Chalk White');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [generatedCode, setGeneratedCode] = useState('');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    // Generate exclusive VIP voucher code
    const randomHex = Math.random().toString(36).substring(2, 6).toUpperCase();
    const code = `VIP-BLANC-01-${randomHex}`;
    setGeneratedCode(code);
    setIsSubmitted(true);
  };

  const copyCode = () => {
    navigator.clipboard.writeText(generatedCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleReset = () => {
    setIsSubmitted(false);
    setEmail('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white border border-zinc-200 max-w-lg w-full p-8 relative shadow-2xl">
        <button
          type="button"
          onClick={onClose}
          className="absolute top-5 right-5 text-zinc-400 hover:text-zinc-900 transition-colors"
          aria-label="Schließen"
        >
          <X className="w-5 h-5" />
        </button>

        {!isSubmitted ? (
          <div>
            <div className="flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-zinc-400 mb-2">
              <Lock className="w-3.5 h-3.5" />
              <span>Geschlossener Vorab-Zugang</span>
            </div>

            <h3 className="text-2xl font-light text-zinc-950 font-editorial">
              VIP-Zugang zu Drop 01 ({brandSettings.dropDate})
            </h3>
            <p className="text-xs text-zinc-600 mt-2 font-light leading-relaxed">
              Trage dich ein, um 2 Stunden vor dem öffentlichen Launch deinen privaten Bestell-Link und dein reserviertes Größenkontingent zu erhalten.
            </p>

            <form onSubmit={handleSubmit} className="mt-6 space-y-4">
              <div>
                <label className="block text-xs uppercase tracking-wider text-zinc-500 mb-1">
                  E-Mail-Adresse *
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@domain.de"
                  className="w-full px-4 py-3 bg-white border border-zinc-200 text-sm focus:border-zinc-950 focus:outline-none transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-zinc-500 mb-1">
                  Vollständiger Name (optional)
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Max Mustermann"
                  className="w-full px-4 py-3 bg-white border border-zinc-200 text-sm focus:border-zinc-950 focus:outline-none transition-colors"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs uppercase tracking-wider text-zinc-500 mb-1">
                    Wunschgröße
                  </label>
                  <select
                    value={sizePreference}
                    onChange={(e) => setSizePreference(e.target.value as ProductSize)}
                    className="w-full px-3 py-3 bg-white border border-zinc-200 text-sm focus:border-zinc-950 focus:outline-none"
                  >
                    <option value="XS">Größe XS</option>
                    <option value="S">Größe S</option>
                    <option value="M">Größe M</option>
                    <option value="L">Größe L</option>
                    <option value="XL">Größe XL</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs uppercase tracking-wider text-zinc-500 mb-1">
                    Bevorzugter Farbton
                  </label>
                  <select
                    value={colorPreference}
                    onChange={(e) => setColorPreference(e.target.value)}
                    className="w-full px-3 py-3 bg-white border border-zinc-200 text-sm focus:border-zinc-950 focus:outline-none"
                  >
                    <option value="Chalk White">Chalk White</option>
                    <option value="Pitch Black">Pitch Black</option>
                    <option value="Oatmeal Melange">Oatmeal Melange</option>
                  </select>
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-4 bg-zinc-950 hover:bg-zinc-800 text-white font-medium text-xs tracking-[0.18em] uppercase transition-colors"
                >
                  VIP-Zugangscode anfordern
                </button>
              </div>

              <p className="text-[11px] text-zinc-400 text-center">
                Kein Spam. Ausschließlich 1 E-Mail zur Veröffentlichung des Drops im {brandSettings.dropDate}.
              </p>
            </form>
          </div>
        ) : (
          <div className="text-center py-4 space-y-6">
            <div className="w-12 h-12 mx-auto rounded-full bg-zinc-100 flex items-center justify-center text-zinc-950">
              <CheckCircle2 className="w-6 h-6" />
            </div>

            <div>
              <h3 className="text-2xl font-light text-zinc-950 font-editorial">
                Zugang erfolgreich registriert
              </h3>
              <p className="text-xs text-zinc-600 mt-2 font-light">
                Deine Vorab-Priorität für Größe {sizePreference} ({colorPreference}) wurde im Atelier-System hinterlegt.
              </p>
            </div>

            {/* Personalized Pass Card */}
            <div className="p-5 bg-zinc-50 border border-zinc-200 text-left space-y-3">
              <div className="flex items-center justify-between text-xs text-zinc-400 uppercase tracking-widest border-b border-zinc-200 pb-2">
                <span>Atelier Drop Pass</span>
                <span>{brandSettings.editionCode}</span>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[10px] uppercase text-zinc-400 block tracking-wider">
                    Persönlicher VIP-Token
                  </span>
                  <span className="font-mono text-base font-semibold text-zinc-950 tracking-wider">
                    {generatedCode}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={copyCode}
                  className="p-2 border border-zinc-200 hover:border-zinc-950 bg-white text-zinc-700 hover:text-zinc-950 transition-colors flex items-center gap-1 text-xs"
                >
                  {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                  <span>{copied ? 'Kopiert' : 'Kopieren'}</span>
                </button>
              </div>
              <p className="text-[11px] text-zinc-500 pt-1">
                Halte diesen Code bereit. Er gewährt dir am Releasetag bevorzugten Zugriff auf den limitierten Bestand.
              </p>
            </div>

            <button
              type="button"
              onClick={handleReset}
              className="w-full py-3 bg-zinc-950 text-white text-xs uppercase tracking-widest font-medium hover:bg-zinc-800 transition-colors"
            >
              Schließen & Zurück zur Kollektion
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
