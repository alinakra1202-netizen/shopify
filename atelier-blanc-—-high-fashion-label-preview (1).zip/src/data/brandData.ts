import { BrandSettings, ProductDetailItem, UpcomingSilhouette } from '../types';

export const initialBrandSettings: BrandSettings = {
  brandName: 'ATELIER BLANC',
  tagline: 'Radikale Silhouette-Präzision & Pure Textilsubstanz',
  dropDate: 'November 2026',
  editionCode: 'FIRST DROP',
  limitedPiecesCount: 150,
  currency: '€',
  price: 185,
};

export const debutProduct: ProductDetailItem = {
  id: 'edition-01-knit',
  name: 'Der Sculpted Heavyweight Knit',
  subtitle: 'Boxy Drop Shoulder Silhouette · 600 GSM',
  edition: 'Edition 01 / Debüt Stück',
  price: 185,
  sku: 'ABL-ED01-SW01',
  description:
    'Konstruiert aus einer schweren Mischung aus gekämmter Bio-Baumwolle und feiner Merinowolle. Der Schnitt zeichnet sich durch markant überschnittene Schultern, einen formstabilen 2x2 Doppelripp-Kragen und eine verkürzte, kastenförmige Länge aus. Keine sichtbaren Logos — die Form und der Stofffall sprechen für sich.',
  composition: '75% GOTS-zertifizierte Bio-Baumwolle, 25% RWS-zertifizierte Merinowolle',
  weightGsm: 600,
  origin: 'Handgefertigt in Nordportugal (Guimarães)',
  colorways: [
    {
      id: 'chalk-white',
      name: 'Chalk White',
      label: 'Rohweiß / Naturkreide',
      hex: '#F9F8F5',
      borderHex: '#E5E4E0',
      previewImage: '/src/assets/images/hero_fashion_pullover_1791734224058.jpg',
    },
    {
      id: 'off-black',
      name: 'Pitch Black',
      label: 'Tiefschwarz / Matt',
      hex: '#141415',
      borderHex: '#27272A',
      previewImage: '/src/assets/images/lookbook_pullover_editorial_1791734234598.jpg',
    },
    {
      id: 'oat-melange',
      name: 'Oatmeal Melange',
      label: 'Hafer-Melange Ungefärbt',
      hex: '#E7DFD5',
      borderHex: '#D4C9BC',
      previewImage: '/src/assets/images/product_knit_detail_1791734246566.jpg',
    },
  ],
  images: {
    hero: '/src/assets/images/hero_fashion_pullover_1791734224058.jpg',
    lookbook: '/src/assets/images/lookbook_pullover_editorial_1791734234598.jpg',
    detail: '/src/assets/images/product_knit_detail_1791734246566.jpg',
    atelier: '/src/assets/images/atelier_silhouette_preview_1791734258501.jpg',
  },
  specs: [
    { label: 'Stoffgewicht', value: '600 Gramm / m² (Ultra Heavyweight Knit)' },
    { label: 'Passform', value: 'Boxy Relaxed Fit mit Drop-Shoulder' },
    { label: 'Kragenkonstruktion', value: '3,8 cm doppelt verstärkter Rippkragen' },
    { label: 'Saumabschluss', value: 'Entspannt fallend, nicht einschneidend' },
    { label: 'Färbung', value: 'Schonende Reaktivfärbung ohne giftige Weichmacher' },
    { label: 'Fertigungsmenge', value: 'Streng nummeriert auf 150 Exemplare weltweit' },
  ],
  sizingNotes:
    'Entworfen mit zeitgemäßem, strukturiertem Boxy Schnitt. Geeignet in deiner normalen Konfektionsgröße für den beabsichtigten Fashion Oversize Look. Eine Größe kleiner wählen für einen klassischeren Sitz.',
};

export const upcomingSilhouettesData: UpcomingSilhouette[] = [
  {
    id: 'silh-02',
    number: '02',
    name: 'Die Wide-Leg Pleated Trouser',
    category: 'Hosen',
    stage: 'Schnittkonstruktion',
    plannedRelease: 'Anfang 2027',
    description:
      'Eine fließende, weite Hose mit tiefer doppelter Bundfalte und präzise kalkuliertem Bruch am Knöchel. Entwickelt als architektonisches Gegenstück zum Edition 01 Knit.',
    materialNotes: '380 GSM Schurwoll-Flanell aus Biella, Italien',
    silhouetteType: 'High-Rise Wide Leg mit cleaner Bundführung',
  },
  {
    id: 'silh-03',
    number: '03',
    name: 'Das Heavy Interlock Tee',
    category: 'Basics / Tops',
    stage: 'Stoff-Testing',
    plannedRelease: 'Frühjahr 2027',
    description:
      '300 GSM dicht gewebter Interlock-Jersey. Fällt steif genug, um eine skulpturale Kante zu halten, fühlt sich kühl und glatt auf der Haut an.',
    materialNotes: '100% gekämmte Suvin-Baumwolle',
    silhouetteType: 'Kastenförmiger Schnitt mit hohem Halsabschluss',
  },
  {
    id: 'silh-04',
    number: '04',
    name: 'Der Structured Raglan Overcoat',
    category: 'Outerwear',
    stage: 'Atelier-Fitting',
    plannedRelease: 'Herbst 2027',
    description:
      'Ein bodenlanger Mantel mit fließender Raglannaht, verdeckter Knopfleiste und breitem Revers. Ungefüttert konstruiert, um das Handwerk sichtbar zu machen.',
    materialNotes: '720 GSM Double-Face Wollkammgarn',
    silhouetteType: 'Oversized Kokon-Silhouette',
  },
];

export const lookbookItems = [
  {
    id: 'lb-1',
    image: '/src/assets/images/hero_fashion_pullover_1791734224058.jpg',
    title: 'Look 01: Monolithischer Fall',
    location: 'Studio White Space, Lichtachse Nord',
    caption: 'Der 600 GSM Knit fällt senkrecht ohne einzuknicken. Kombiniert mit weiter Tailored Trouser in Ecru.',
  },
  {
    id: 'lb-2',
    image: '/src/assets/images/lookbook_pullover_editorial_1791734234598.jpg',
    title: 'Look 02: High Neck und Silhouette',
    location: 'Architectural Void',
    caption: 'Erweiterte Kragenpartie für kühle Tage. Skulpturaler Ärmelverlauf mit verstärkten Bündchen.',
  },
  {
    id: 'lb-3',
    image: '/src/assets/images/product_knit_detail_1791734246566.jpg',
    title: 'Look 03: Die Webkante im Detail',
    location: 'Textillabor Guimarães',
    caption: 'Gleichmäßige Maschendichte und handgekettelte Schulternähte für lebenslange Formstabilität.',
  },
  {
    id: 'lb-4',
    image: '/src/assets/images/atelier_silhouette_preview_1791734258501.jpg',
    title: 'Look 04: Entstehung im Atelier',
    location: 'Atelier Paris / Berlin',
    caption: 'Von der Schnittskizze über 6 Prototyp Iterationen bis zur finalen Webdichte.',
  },
];
