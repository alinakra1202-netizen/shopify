import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  app.use(express.json({ limit: '100mb' }));
  app.use(express.urlencoded({ extended: true, limit: '100mb' }));

  const mediaFilePath = path.join(__dirname, 'public', 'uploaded_media.json');

  // API to get saved media
  app.get('/api/media', (_req, res) => {
    try {
      if (fs.existsSync(mediaFilePath)) {
        const data = fs.readFileSync(mediaFilePath, 'utf-8');
        return res.json(JSON.parse(data));
      }
    } catch (e) {
      console.error('Error reading uploaded_media.json', e);
    }
    return res.json({ logo: null, bgPhoto: null });
  });

  // API to save uploaded media permanently to disk
  app.post('/api/media', (req, res) => {
    try {
      const { logo, bgPhoto } = req.body;
      let existing: { logo: string | null; bgPhoto: string | null } = { logo: null, bgPhoto: null };
      if (fs.existsSync(mediaFilePath)) {
        try {
          existing = JSON.parse(fs.readFileSync(mediaFilePath, 'utf-8'));
        } catch {}
      }

      let savedLogo = existing.logo;
      let savedBg = existing.bgPhoto;

      if (logo && typeof logo === 'string' && logo.startsWith('data:image')) {
        try {
          const base64Data = logo.replace(/^data:image\/\w+;base64,/, '');
          const ext = logo.split(';')[0].split('/')[1] || 'png';
          const filename = `custom_brand_logo.${ext}`;
          fs.writeFileSync(path.join(__dirname, 'public', filename), base64Data, 'base64');
          savedLogo = `/${filename}`;
        } catch (err) {
          console.error('Failed to save logo file', err);
          savedLogo = logo;
        }
      } else if (logo) {
        savedLogo = logo;
      }

      if (bgPhoto && typeof bgPhoto === 'string' && bgPhoto.startsWith('data:image')) {
        try {
          const base64Data = bgPhoto.replace(/^data:image\/\w+;base64,/, '');
          const ext = bgPhoto.split(';')[0].split('/')[1] || 'png';
          const filename = `custom_hero_bg.${ext}`;
          fs.writeFileSync(path.join(__dirname, 'public', filename), base64Data, 'base64');
          savedBg = `/${filename}`;
        } catch (err) {
          console.error('Failed to save bg file', err);
          savedBg = bgPhoto;
        }
      } else if (bgPhoto) {
        savedBg = bgPhoto;
      }

      const updated = {
        logo: savedLogo,
        bgPhoto: savedBg,
      };

      fs.writeFileSync(mediaFilePath, JSON.stringify(updated, null, 2), 'utf-8');
      console.log('Successfully saved uploaded media to disk permanently:', updated);
      return res.json({ success: true, data: updated });
    } catch (e) {
      console.error('Error saving uploaded_media.json', e);
      return res.status(500).json({ error: 'Failed to save media' });
    }
  });

  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
